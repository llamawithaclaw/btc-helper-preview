# SHED Emergency-Buffer Codebook Appendix

## Purpose

This appendix summarizes the variables and constructs used in the SHED emergency-buffer replication package. It is not a replacement for the Federal Reserve SHED codebooks. It is a working replication appendix that records how the public notes currently use the variables, what years are usable, and where harmonization limits remain.

## Measurement hierarchy

### 1. Official benchmark first

For public trend claims about whether adults can cover a $400 emergency expense with cash or equivalent, the Federal Reserve published SHED top-line series remains the benchmark.

### 2. Direct recent microdata second

In recent public-use microdata, `pay_casheqv` is the direct cash/equivalent variable aligned with the official concept. It is available in inspected files from 2020 onward.

### 3. Component rules are diagnostic only

Before `pay_casheqv` appears in the inspected files, component variables such as `EF3_a` and `EF3_c` can approximate parts of the concept, but they overstate the direct/official cash-equivalent measure in overlap years. They should not be used as if they were the official measure.

## Key constructs

| Construct | Main variables | Current use | Boundary |
|---|---|---|---|
| $400 cash/equivalent capacity | `pay_casheqv`, `EF3_a`, `EF3_c` | Official benchmark trend; direct microdata analysis where available; bridge diagnostics | Component-built pre-2020 values are diagnostic only. |
| Three-month emergency savings | `EF1` | Repeated-cross-section savings-buffer measure | Cross-sectional; not within-person accumulation. |
| Financial well-being / vulnerability | `B2`, `atleast_okay` | Descriptive subgroup and adjusted analyses | Subjective status, not a balance-sheet measure. |
| Bill pressure | `EF5C`, `EF5D` | Limited recent-window hardship diagnostic | Not comparable enough for a 2015–2025 headline trend. |
| Credit-card pay-over-time response | `EF3_b` | Distress/borrowing-style response to emergency expense | Distinct from cash/equivalent capacity. |
| Covariates | `inc_4cat_50k`, `ppinc7`, `ppagect4`, `ppagecat`, `educ_4cat`, `ppeducat`, `race_5cat`, `ppethm`, `pprent`, `ppemploy`, `ppkid017`, `ppreg4` | Descriptive heterogeneity and approximate adjusted models | Public-use categories are coarse; adjusted models are descriptive, not causal. |

## Year availability summary

The raw-variable presence table is generated in:

- `shed_replication_raw_variable_presence.csv`
- `shed_replication_variable_map.md`

Important current availability facts:

- `EF1`, `EF3_a`, `EF3_b`, and `EF3_c` are present for 2015–2025 in the inspected files.
- `pay_casheqv` is present for 2020–2025.
- `atleast_okay`, `inc_4cat_50k`, `educ_4cat`, and `race_5cat` are present for 2020–2025.
- `ppinc7`, `ppemploy`, and `ppkid017` are present for 2021–2025.
- Bill-pressure variables are later and less stable: `EF5C` appears in 2023–2025 and `EF5D` appears in 2025.

## Denominator rules

Current generated tables generally use:

- adult respondents in the relevant SHED public-use file;
- positive final weights;
- nonmissing construct value;
- nonmissing covariates where adjusted or subgroup analysis requires them.

For the official benchmark, the published Federal Reserve top-line series remains authoritative even when author-constructed microdata diagnostics differ.

## Missing / invalid handling

Current scripts treat blank, refused, don't-know, inapplicable, and otherwise non-valid responses as missing for the construct being estimated. A future final archive should document exact response-code handling wave by wave using extracted codebook text.

## Inference status

Current intervals and adjusted models are approximate weighted diagnostics. They do not yet claim full SHED complex-survey design inference. The public note should continue to describe them as approximate unless a later variance-design pass validates a stronger approach.

## Public wording rule

Use this phrasing when summarizing the measurement boundary:

> The Federal Reserve official $400 cash/equivalent series remains the benchmark. Recent direct microdata align more closely with that concept, while pre-2020 component-built measures are diagnostic and should not be treated as equivalent to the official trend.
