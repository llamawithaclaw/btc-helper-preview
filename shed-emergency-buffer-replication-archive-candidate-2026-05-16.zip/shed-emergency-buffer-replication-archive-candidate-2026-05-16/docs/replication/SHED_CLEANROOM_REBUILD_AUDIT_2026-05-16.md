# SHED Clean-Room Rebuild Audit

_Date: 2026-05-16_

Status: **reproducible_with_pdf_binary_metadata_variance**

Clean-room directory: `/tmp/shed-cleanroom-20260516`

| File | Match | Bytes | SHA-256 |
|---|---:|---:|---|
| `docs/replication/shed_source_provenance.csv` | yes | 6363 | `afdde26c9221079d...` |
| `tables/shed_replication_variable_map.csv` | yes | 4128 | `c329884471eae291...` |
| `docs/replication/shed_replication_variable_map.md` | yes | 4081 | `43ed58993e7cc3e2...` |
| `docs/replication/shed_official_topline_reproduction.md` | yes | 1098 | `6cb66dc1cdf5414f...` |
| `docs/replication/shed_pay_casheqv_component_bridge.md` | yes | 775 | `ffd09afc51309c74...` |
| `docs/replication/shed_public_archive_manifest.json` | yes | 14262 | `80ad2c320af020c3...` |
| `data/processed/shed_2015_2025_harmonized_panel.csv` | yes | 14750701 | `e25f1cb096cf0109...` |
| `tables/shed_official_topline_reproduction.csv` | yes | 722 | `5f1aa1e0c9a71615...` |
| `tables/shed_2015_2025_harmonized_trends.csv` | yes | 10438 | `ffc1000d0afe7971...` |
| `exports/SHED_Emergency_Buffer_Replication_Methodology_Draft.html` | yes | 27110 | `81f75ea500a35e21...` |
| `exports/SHED_Emergency_Buffer_Replication_Methodology_Draft.pdf` | text-only; binary metadata differs | 148874 | `61681a520895bc8c...` |

## PDF render note

PDF binary checksums differ across source and clean-room renders, but extracted PDF text equivalence is **yes**. This is treated as renderer metadata/timestamp variance unless future content differences appear.
