# SHED Public Archive Candidate

_Date: 2026-05-16_

## Status

This is a **public archive candidate** for the SHED emergency-buffer replication scaffold. It is not described as a final certified journal replication package.

## Candidate bundle

Version label: `shed-emergency-buffer-replication-archive-candidate-2026-05-16`

The bundle includes public documentation, scripts, aggregate tables, rendered methodology exports, provenance files, and manifests. It intentionally excludes raw Federal Reserve SHED public-use ZIP files and person-level processed extracts.

## Clean-room rebuild result

A fresh-directory rebuild was run in `/tmp/shed-cleanroom-20260516` using:

```bash
python3 scripts/run_shed_replication_package.py
```

Result: **reproducible with PDF binary metadata variance**.

- Data, documentation, aggregate tables, manifest, and HTML outputs matched by SHA-256.
- Methodology PDF extracted text matched exactly.
- PDF binary checksums differed despite identical byte size and text, consistent with renderer metadata/timestamp variance.

See:

- `SHED_CLEANROOM_REBUILD_AUDIT_2026-05-16.md`
- `SHED_CLEANROOM_REBUILD_AUDIT_2026-05-16.json`

## Included by design

- Public documentation and README files.
- Source provenance and source checksums.
- Variable map and codebook appendix.
- Official-topline benchmark reproduction.
- Bridge diagnostics for `pay_casheqv` versus component-built rules.
- Harmonized aggregate tables and heterogeneity diagnostics.
- Methodology manuscript and rendered HTML/PDF.
- Rebuild scripts.

## Excluded by design

- `data/raw/SHED_public_use_data_*_CSV.zip`
- `data/raw/SHED_2025codebook.pdf`
- person-level processed CSV extracts, including `data/processed/shed_2015_2025_harmonized_panel.csv`
- Python `__pycache__` artifacts

The public archive posture is to document official source URLs and checksums, provide rebuild scripts, and avoid redistributing respondent-level files unless a later source/legal review explicitly approves it.

## Remaining upgrades

1. Exact wave-by-wave codebook question text extraction for every variable.
2. Survey-design variance if sufficient public design information is available.
3. External release decision: downloadable ZIP, GitHub release, or documented folder only.
