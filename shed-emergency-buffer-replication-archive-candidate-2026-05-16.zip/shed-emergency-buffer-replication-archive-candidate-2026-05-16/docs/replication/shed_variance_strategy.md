# SHED Variance Strategy and Limits

The current replication package reports approximate weighted confidence intervals using final weights and a Kish-style effective sample size. This is useful for scale and transparency, but it is not a full survey-design variance estimator.

## Current strategy

- Use final respondent weights where available.
- Compute weighted proportions.
- Approximate effective sample size as `(sum w)^2 / sum(w^2)`.
- Use normal-approximation intervals for descriptive proportions.
- Use heteroskedasticity-robust weighted linear probability models for adjusted descriptive associations.

## Limits

- The current scripts do not use replicate weights, strata, or primary sampling units.
- Confidence intervals should be treated as approximate.
- Adjusted models are descriptive controls, not causal designs.
- Public-use variable harmonization, skip patterns, and question wording remain at least as important as sampling variance for the main measurement claims.

## Publication-grade upgrade

A publication-grade release should either implement the Federal Reserve's recommended survey-design variance approach for the relevant SHED files or explicitly justify why final-weight/Kish approximations are adequate for a public measurement note.
