# SHED Official Topline Reproduction / Benchmark

This table treats the Federal Reserve published SHED $400 cash/equivalent series as the benchmark. The microdata component diagnostic is shown to document why pre-2020 values cannot be used as the same measure.

| Year | Official % | Microdata diagnostic % | Diff pp | Status |
|---|---|---|---|---|
| 2015 | 54.0 | 66.0 | 12.0 | component diagnostic not equivalent |
| 2016 | 56.0 | 68.7 | 12.7 | component diagnostic not equivalent |
| 2017 | 59.0 | 71.6 | 12.6 | component diagnostic not equivalent |
| 2018 | 61.0 | 69.1 | 8.1 | component diagnostic not equivalent |
| 2019 | 63.0 | 72.0 | 9.0 | component diagnostic not equivalent |
| 2020 | 64.0 | 64.6 | 0.6 | direct/near-direct validation window |
| 2021 | 68.0 | 67.7 | -0.3 | direct/near-direct validation window |
| 2022 | 63.0 | 65.0 | 2.0 | direct/near-direct validation window |
| 2023 | 63.0 | 63.3 | 0.3 | direct/near-direct validation window |
| 2024 | 63.0 | 62.7 | -0.3 | direct/near-direct validation window |
| 2025 | 63.0 | 63.1 | 0.1 | direct/near-direct validation window |
