# SHED public archive manifest

This manifest lists files included in the SHED emergency-buffer replication archive. It intentionally excludes raw SHED public-use ZIP files and person-level processed extracts; source files should be obtained from Federal Reserve URLs documented in `shed_source_provenance.md`.

| Path | Role | Bytes | SHA-256 | Notes |
|---|---:|---:|---|---|
| `README.md` | documentation | 297 | `de5b3734a7cfd59360a5d11ad0cac8bc3d73503750591252717bdfc00856c6c3` | Public replication package artifact. |
| `archive_file_list.txt` | documentation | 2284 | `5600c39a9bd4719ca39ae69761c0c413d8bf4f63af533c75909a0c95e13f6fa9` | Public replication package artifact. |
| `docs/replication/PUBLIC_ARCHIVE_README.md` | documentation | 4798 | `68e01c144733f3db085f77c97a130f9ef8ac11ecd36fb898b4b5aedcf7825fba` | Public replication package artifact. |
| `docs/replication/README.md` | documentation | 4584 | `40255920f06487cc0b5e0794f5eb117733232788c0d1c26eff822a8abe4b1e28` | Public replication package artifact. |
| `docs/replication/SHED_CLEANROOM_REBUILD_AUDIT_2026-05-16.json` | documentation | 3898 | `35df8d2526a051dbacec3741a05c41e3969ca082d4596f14e5af0e1b8dab558a` | Public replication package artifact. |
| `docs/replication/SHED_CLEANROOM_REBUILD_AUDIT_2026-05-16.md` | documentation | 1530 | `b02a63d6e75299eed0cc22782793d4b02d930b6bfdef243e6c1f46319d274bda` | Public replication package artifact. |
| `docs/replication/SHED_PUBLIC_ARCHIVE_CANDIDATE_2026-05-16.md` | documentation | 2268 | `a39a9ff082f996e765e73e9d402dfb6b9bf4dacd621e7af3a3ede93899e9b9dd` | Public replication package artifact. |
| `docs/replication/SHED_REPLICATION_CODEBOOK_APPENDIX.md` | documentation | 4311 | `7350a07b9ee90225681c45a84fe7affa61f68e84892a7258fe0af2c3380777e6` | Public replication package artifact. |
| `docs/replication/cleanroom_source_rebuild_log_2026-05-16.json` | documentation | 2343 | `aa9afb28e122bf7af391573635f006f1b353434e904e084835810ff0fc8c6b83` | Public replication package artifact. |
| `docs/replication/shed_2021_2025_heterogeneity.md` | documentation | 1118 | `5932c519c126f18b8b857ed6e89aa33204828896a5e2f8968366acab766427c4` | Public replication package artifact. |
| `docs/replication/shed_bridge_by_year_group_alternatives.md` | documentation | 1626 | `92d6a49f7e1191f4bb61fdbbaa8e6b5f99b1b7b7c3846a170c23752de5915a3d` | Public replication package artifact. |
| `docs/replication/shed_official_topline_reproduction.md` | documentation | 1098 | `6cb66dc1cdf5414f22b0aab17aeb60a67cc3fdb982fb3a3646297fe59e916755` | Public replication package artifact. |
| `docs/replication/shed_pay_casheqv_component_bridge.json` | documentation | 2424 | `5be48fa8a1fd28527e92402e5af2a55f9e04620b36a4c017fc7e0b7383e2ca0c` | Public replication package artifact. |
| `docs/replication/shed_pay_casheqv_component_bridge.md` | documentation | 775 | `ffd09afc51309c74a781f1317ca3592f4e62966de0d3b74275ace6986a9875de` | Public replication package artifact. |
| `docs/replication/shed_replication_variable_map.md` | documentation | 4081 | `43ed58993e7cc3e296165d7adf8f6dd0c9f9ae99fb4bb197a8acd2f80f6413f5` | Public replication package artifact. |
| `docs/replication/shed_source_provenance.csv` | documentation | 6363 | `afdde26c9221079ddcc1cfabd1bc539c760e73f9823bbba81988657b4ad03cf0` | Public replication package artifact. |
| `docs/replication/shed_source_provenance.json` | documentation | 11255 | `590080f8dc4b57ba622af4243c401fa0823454f3e7069c5d4ffa924f33af63fd` | Public replication package artifact. |
| `docs/replication/shed_source_provenance.md` | documentation | 2779 | `edbdf4c9c755ece6a27aeaf98676537be285241c3775df475ab50a1e2df02e00` | Public replication package artifact. |
| `docs/replication/shed_variance_strategy.md` | documentation | 1270 | `38d99355b6fa107322ac38f68fc677361e718f5e71a541d084d58497d04c71bf` | Public replication package artifact. |
| `docs/replication/software_environment.json` | documentation | 589 | `e0a6013c4ea9e7b47f707a773978693801d222aa6f36623cd1b368c6feb0428a` | Public replication package artifact. |
| `docs/replication/software_environment.md` | documentation | 316 | `ffb5dc49c7f1904f555651170f0dd9c5e3b21acc04db3f504c382ba7fa7e1124` | Public replication package artifact. |
| `exports/SHED_Emergency_Buffer_Replication_Methodology_Draft.html` | rendered export | 27110 | `81f75ea500a35e218f77cf9421f44269b9ad6e236ce160ff5ecce7ff5935a351` | Public derived/source artifact; raw SHED ZIPs are not bundled and should be downloaded from Federal Reserve sources. |
| `exports/SHED_Emergency_Buffer_Replication_Methodology_Draft.pdf` | rendered export | 148874 | `61681a520895bc8cc7e361b18f744d3d25ebc34f8e1cef1887cd59562dc728e7` | Public derived/source artifact; raw SHED ZIPs are not bundled and should be downloaded from Federal Reserve sources. |
| `manuscript/shed_replication_methodology_finished_draft.md` | source manuscript | 21077 | `c89957d03ff3d86ae35e9e05e6f1fb0ae906386508011a46d73e9eab4cd1c44a` | Public replication package artifact. |
| `scripts/build_phase_a_2025.py` | rebuild script | 17197 | `734fe4a638c6b2a118e1f4346f689e1d9220940db8ca414a6bbe1b7d8bdd5f38` | Public replication package artifact. |
| `scripts/build_shed_harmonized_panel.py` | rebuild script | 15495 | `bc119259cae8c29d95525c4cd063d6f8fba6cb26945a36a4be81cde33c2e8573` | Public replication package artifact. |
| `scripts/build_shed_overlap_bridge.py` | rebuild script | 5513 | `1c43a7e6141b09554236eee48c0b9bc561479d2621d0046436670591d7979add` | Public replication package artifact. |
| `scripts/build_shed_replication_hardening.py` | rebuild script | 19741 | `7c56843ff85cee586ae7f453acd46c51cb142d58a53b7e56a9688d3d506e10b9` | Public replication package artifact. |
| `scripts/build_shed_replication_provenance.py` | rebuild script | 6781 | `5450085ba5dfc4e786c94770041b135085c1599db180b3c3d087bd99db2dff39` | Public replication package artifact. |
| `scripts/export_harmonized_paper.py` | rebuild script | 5045 | `03acc87188c11e12b2dc8610cae46f1b69bb1d151da122590d8aa1e3eb29d810` | Public replication package artifact. |
| `scripts/export_paper_xi_html_pdf.py` | rebuild script | 6513 | `1162c22144db849eca01e1a14cb2d1cac4a33fae3b8ed4dcec0c97c7ee41d89e` | Public replication package artifact. |
| `scripts/export_shed_replication_methodology.py` | rebuild script | 6330 | `0d8ec9e9052aa93b7352f55a9c38906420d54effbc1c3eda0b826c10e4c7fe62` | Public replication package artifact. |
| `scripts/run_shed_replication_package.py` | rebuild script | 1303 | `17278a6ac0f33a9156d9f16a49853fc8091f62174d30e3c80b3241c20d23265d` | Public replication package artifact. |
| `tables/shed_2013_2025_harmonization_manifest.csv` | generated table | 1107 | `a3b5093c783eba8069c6e2ca37431b3c849ef3e0ba5875cafa8ec23fd582a185` | Public derived/source artifact; raw SHED ZIPs are not bundled and should be downloaded from Federal Reserve sources. |
| `tables/shed_2013_2025_harmonization_manifest.md` | generated table | 1099 | `531ab4cf26a1727c869b8e8eb3ccd5a17f55bed483afd3e8ad13bfaaf7869e39` | Public derived/source artifact; raw SHED ZIPs are not bundled and should be downloaded from Federal Reserve sources. |
| `tables/shed_2015_2025_harmonized_trends.csv` | generated table | 10438 | `ffc1000d0afe7971ed0e6ec16d4df100888e0bcda0c589ff73d98f2fc716940d` | Public derived/source artifact; raw SHED ZIPs are not bundled and should be downloaded from Federal Reserve sources. |
| `tables/shed_2020_2025_cash_equiv_crosstabs.csv` | generated table | 1107 | `ca56a0dfff801dc326fd938f37af3bbf951465263ada6d16303f67a1674950ae` | Public derived/source artifact; raw SHED ZIPs are not bundled and should be downloaded from Federal Reserve sources. |
| `tables/shed_2020_2025_pay_casheqv_component_bridge.csv` | generated table | 988 | `3d3995d003bce0df38fcb613fbd425b4c4379f2c62f5b01fa0f6777658cc8753` | Public derived/source artifact; raw SHED ZIPs are not bundled and should be downloaded from Federal Reserve sources. |
| `tables/shed_2021_2025_adjusted_lpm.csv` | generated table | 665 | `38c7ef96a2fe2f218cc9ebe643f9712d630451d02275f31f4b047012ce29b28d` | Public derived/source artifact; raw SHED ZIPs are not bundled and should be downloaded from Federal Reserve sources. |
| `tables/shed_2021_2025_replication_heterogeneity.csv` | generated table | 1145 | `81b22c34a953e6b8f6df21c58d08b655ac533136844cccb4b23ece14791fe759` | Public derived/source artifact; raw SHED ZIPs are not bundled and should be downloaded from Federal Reserve sources. |
| `tables/shed_bridge_by_year_group_alternatives.csv` | generated table | 3125 | `bbe771dc1d1fd0e1917b7d2c527db19e11fea6848a3e628baa3862ea456a20e1` | Public derived/source artifact; raw SHED ZIPs are not bundled and should be downloaded from Federal Reserve sources. |
| `tables/shed_harmonized_multi_year_tables.md` | generated table | 2802 | `b9dc8f4fe9c91b8be6428ffd632a360245876b3be4f19e120fe60b2204ed02b3` | Public derived/source artifact; raw SHED ZIPs are not bundled and should be downloaded from Federal Reserve sources. |
| `tables/shed_official_cash_equiv_benchmark.csv` | generated table | 632 | `cd6b881122e891fce52bb3142f63f15360e85a42bcf76de660faad5959c150de` | Public derived/source artifact; raw SHED ZIPs are not bundled and should be downloaded from Federal Reserve sources. |
| `tables/shed_official_topline_reproduction.csv` | generated table | 722 | `5f1aa1e0c9a716153207a776fda36373b86e1d9e3fd23bef24ef23df6b53d991` | Public derived/source artifact; raw SHED ZIPs are not bundled and should be downloaded from Federal Reserve sources. |
| `tables/shed_replication_raw_variable_presence.csv` | generated table | 1576 | `ac104ea43c4ba5d28eead4786cca632110ada12b6c45649f4a701ac224fe1a11` | Public derived/source artifact; raw SHED ZIPs are not bundled and should be downloaded from Federal Reserve sources. |
| `tables/shed_replication_variable_map.csv` | generated table | 4128 | `c329884471eae291102e6e3cecbd79ae96e382ccf0f89bc2302ddfc981fb8cb4` | Public derived/source artifact; raw SHED ZIPs are not bundled and should be downloaded from Federal Reserve sources. |
