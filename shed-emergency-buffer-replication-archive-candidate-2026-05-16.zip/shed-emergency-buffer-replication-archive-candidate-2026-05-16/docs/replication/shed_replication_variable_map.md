# SHED Replication Variable Map

This table is a replication-grade map of the constructs used in the emergency-buffer notes. It separates official published top-line measures from author-constructed diagnostics and records the current harmonization boundary.

| Construct | Raw variables | Usable window | Denominator/coding | Key caveat |
|---|---|---|---|---|
| cash_equiv_400 | `pay_casheqv; EF3_a; EF3_c` | Official benchmark 2015-2025; direct microdata pay_casheqv 2020-2025; component diagnostic only before 2020 | Adults with valid emergency-expense response and positive final weight; official topline uses Federal Reserve published SHED report series. Yes=1, No=0. Before 2020, component-built values are not treated as equivalent to the official/direct measure. | Central measurement caveat: pre-2020 component rule overstates the official series by 8-13 pp and is diagnostic only. |
| three_month_savings | `EF1` | 2015-2025 trend; richer covariate analysis mainly 2021-2025 | Adults with valid EF1 response and positive final weight. Yes=1, No=0. | Repeated cross-section; not within-person savings accumulation. |
| financially_vulnerable / doing_okay | `B2; atleast_okay` | B2-derived coding available broadly; atleast_okay direct variable from 2020 onward in inspected files | Adults with valid financial-well-being response and positive final weight. Doing okay=1 for living comfortably or doing okay; financially vulnerable=1 for just getting by or finding it difficult. | Subjective financial status; not a balance-sheet measure. |
| bill_pressure | `EF5C; EF5D` | Use cautiously; main adjusted analysis limited to 2021-2025, not a 2015-2025 headline trend | Adults with valid bill-pressure response and positive final weight. Coded to indicate bill pressure where comparable in the analysis window. | Definitions are not comparable enough for a full-period trend claim. |
| card_pay_over_time_400 | `EF3_b` | 2015-2025 descriptive series | Adults with valid emergency-expense response and positive final weight. Selected option=1, no/not selected=0. | Not cash-equivalent; explicitly distinct from pay_casheqv. |
| covariates | `inc_4cat_50k; ppinc7; ppagect4; ppagecat; educ_4cat; ppeducat; race_5cat; ppethm; pprent; ppemploy; ppkid017; ppreg4` | Richest consistent adjusted-analysis coverage 2021-2025 | Adults with non-missing construct, outcome, covariates, and positive final weight. Collapsed categories used for descriptive heterogeneity and approximate adjusted models. | Public-use categories are coarse; adjusted models are descriptive, not causal. |

## Raw variable presence

| Raw variable | Years present | N years |
|---|---|---|
| B2 | 2013, 2014, 2015, 2016, 2017, 2018, 2019, 2020, 2021, 2022, 2023, 2024, 2025 | 13 |
| EF1 | 2015, 2016, 2017, 2018, 2019, 2020, 2021, 2022, 2023, 2024, 2025 | 11 |
| EF3_a | 2015, 2016, 2017, 2018, 2019, 2020, 2021, 2022, 2023, 2024, 2025 | 11 |
| EF3_b | 2015, 2016, 2017, 2018, 2019, 2020, 2021, 2022, 2023, 2024, 2025 | 11 |
| EF3_c | 2015, 2016, 2017, 2018, 2019, 2020, 2021, 2022, 2023, 2024, 2025 | 11 |
| EF5C | 2023, 2024, 2025 | 3 |
| EF5D | 2025 | 1 |
| atleast_okay | 2020, 2021, 2022, 2023, 2024, 2025 | 6 |
| educ_4cat | 2020, 2021, 2022, 2023, 2024, 2025 | 6 |
| inc_4cat_50k | 2020, 2021, 2022, 2023, 2024, 2025 | 6 |
| pay_casheqv | 2020, 2021, 2022, 2023, 2024, 2025 | 6 |
| ppagecat | 2014, 2015, 2016, 2017, 2018, 2019, 2020, 2021, 2022, 2023, 2024, 2025 | 12 |
| ppagect4 | 2014, 2015, 2016, 2017, 2018, 2019, 2020, 2021, 2022, 2023, 2024, 2025 | 12 |
| ppeducat | 2015, 2016, 2017, 2018, 2019, 2020, 2021, 2022, 2023, 2024, 2025 | 11 |
| ppemploy | 2021, 2022, 2023, 2024, 2025 | 5 |
| ppethm | 2014, 2015, 2016, 2017, 2018, 2019, 2020, 2021, 2022, 2023, 2024, 2025 | 12 |
| ppinc7 | 2021, 2022, 2023, 2024, 2025 | 5 |
| ppkid017 | 2021, 2022, 2023, 2024, 2025 | 5 |
| ppreg4 | 2014, 2015, 2018, 2019, 2020, 2021, 2022, 2023, 2024, 2025 | 10 |
| pprent | 2014, 2015, 2016, 2017, 2018, 2019, 2020, 2021, 2022, 2023, 2024, 2025 | 12 |
| race_5cat | 2020, 2021, 2022, 2023, 2024, 2025 | 6 |
