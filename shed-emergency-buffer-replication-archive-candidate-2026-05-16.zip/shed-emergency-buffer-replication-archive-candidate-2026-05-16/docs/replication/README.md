# SHED Emergency-Buffer Replication Package Scaffold

This folder is the start of the replication-grade package for **Emergency Buffers Over Time: A SHED Repeated Cross-Section Measurement Note, 2015–2025**.

It exists because the referee report correctly identified that the first harmonized draft needed stronger source provenance, official-topline benchmarking, and bridge diagnostics before any public or publication-facing claims should rely on multi-year harmonization.

## Current contents

- `shed_source_provenance.md` / `.csv` / `.json`  
  Official Federal Reserve SHED CSV/codebook URLs, HEAD checks, local cached ZIP hashes where present, last-updated dates, and known revision notes from the official SHED Data page.

- `shed_pay_casheqv_component_bridge.md` / `.json`  
  Overlap-year bridge diagnostic comparing direct `pay_casheqv` against the simple component rule `EF3_a OR EF3_c` for 2020–2025.

## Key diagnostic result

The bridge diagnostic confirms the measurement problem:

- Direct `pay_casheqv` pooled 2020–2025: **64.1%**
- Component rule pooled 2020–2025: **72.3%**
- Difference: **+8.1 percentage points**

The component rule has a high agreement rate because most respondents agree across both measures, but the false-positive rate is about 8 percentage points. Therefore the component rule should not be treated as equivalent to the Federal Reserve direct/official cash-equivalent measure.

## Scripts

Run from the repository root:

```bash
python3 projects/sound-money-research/papers/paper-xi-shed-microdata/scripts/build_shed_replication_provenance.py
python3 projects/sound-money-research/papers/paper-xi-shed-microdata/scripts/build_shed_overlap_bridge.py
python3 projects/sound-money-research/papers/paper-xi-shed-microdata/scripts/build_shed_harmonized_panel.py
```

## Still needed before publication-grade release

1. Year-by-year codebook variable map for:
   - exact question text;
   - response options;
   - variable names;
   - universe/denominator;
   - multiple-response status;
   - missing/refused/don't-know/inapplicable handling.
2. Official-topline reproduction table for each published SHED benchmark used.
3. Survey-design variance strategy or explicit justification for approximate weighted intervals.
4. Heterogeneity tables by income, housing tenure, age, children, employment, and race/ethnicity.
5. Dependency and software-version capture.
6. One-command reproduction wrapper that rebuilds all tables, manuscript exports, and site artifacts.

## Current status

Scaffold started and two major referee-requested diagnostics are now in place: source provenance and overlap bridge testing.


## Public archive hardening additions — 2026-05-15

Added a public-archive layer on top of the finished-draft replication package:

- `PUBLIC_ARCHIVE_README.md` — public archive boundary, rebuild order, source-data policy, and reproducibility scope.
- `SHED_REPLICATION_CODEBOOK_APPENDIX.md` — construct-level codebook appendix for the core SHED emergency-buffer variables and harmonization limits.
- `shed_public_archive_manifest.md` / `.csv` / `.json` — public archive candidate manifest with file roles, byte sizes, and SHA-256 checksums.

These additions are intended to make the SHED lane easier to freeze later as an external replication archive without accidentally republishing raw respondent-level files or overstating the current inference status.


## Finished-draft replication hardening additions — 2026-05-15

Additional replication-grade artifacts now included:

- `shed_replication_variable_map.md` / `shed_replication_variable_map.csv` — construct-to-variable map, denominators, coding, caveats, and raw-variable year presence.
- `shed_official_topline_reproduction.md` / `shed_official_topline_reproduction.csv` — official Federal Reserve benchmark series versus the microdata diagnostic.
- `shed_2021_2025_heterogeneity.md` / `shed_2021_2025_replication_heterogeneity.csv` — subgroup checks by income, tenure, age, children, employment, and race/ethnicity.
- `shed_variance_strategy.md` — current approximate weighted-interval strategy and publication-grade limits.
- `software_environment.md` / `.json` — local runtime and dependency capture.
- `SHED_Emergency_Buffer_Replication_Methodology_Draft.pdf` — finished methodology/replication draft.

Current status: finished-draft replication package, not final publication-grade archive. Remaining upgrades are exact codebook text extraction for every wave, survey-design variance if available, and a fully frozen public release bundle.
