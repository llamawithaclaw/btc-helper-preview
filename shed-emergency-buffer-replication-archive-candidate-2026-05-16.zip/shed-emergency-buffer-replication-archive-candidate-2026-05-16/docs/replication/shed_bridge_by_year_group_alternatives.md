# SHED Bridge Diagnostics by Year, Group, and Alternative Rule

Direct measure is `pay_casheqv`. The broad component rule is `EF3_a OR EF3_c`. Alternative diagnostics show why no simple component rule should be treated as equivalent without official benchmarking.

## By year

| Group | N | Direct % | OR rule % | Diff pp | Cash-only % | Card-full-only % | AND rule % | False positive % |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| 2020 | 11,648 | 64.6 | 72.2 | 7.6 | 45.1 | 36.1 | 8.9 | 7.6 |
| 2021 | 11,874 | 67.7 | 75.6 | 7.9 | 48.4 | 37.4 | 10.2 | 7.9 |
| 2022 | 9,293 | 63.2 | 70.7 | 7.5 | 43.8 | 35.5 | 8.6 | 7.5 |
| 2023 | 11,400 | 63.3 | 71.7 | 8.4 | 45.0 | 36.9 | 10.2 | 8.4 |
| 2024 | 12,295 | 62.7 | 71.3 | 8.6 | 42.5 | 37.9 | 9.2 | 8.6 |
| 2025 | 12,934 | 63.1 | 71.7 | 8.5 | 43.2 | 38.4 | 9.9 | 8.6 |

## Selected subgroup bridge diagnostics

| Group type | Group | N | Direct % | OR rule % | Diff pp | False positive % |
|---|---|---:|---:|---:|---:|---:|
| Income | $100,000 or more | 24,717 | 86.9 | 92.2 | 5.3 | 5.3 |
| Income | $25,000-$49,999 | 11,520 | 50.6 | 61.0 | 10.4 | 10.4 |
| Income | $50,000-$99,999 | 18,750 | 68.5 | 77.3 | 8.9 | 8.9 |
| Income | Less than $25,000 | 14,350 | 34.0 | 44.1 | 10.1 | 10.1 |
| Age | 18-29 | 10,911 | 51.4 | 64.0 | 12.6 | 12.6 |
| Age | 30-44 | 15,535 | 57.6 | 66.8 | 9.2 | 9.2 |
| Age | 45-59 | 16,523 | 64.6 | 71.7 | 7.1 | 7.1 |
| Age | 60+ | 26,473 | 77.6 | 82.6 | 5.0 | 5.0 |
| Tenure | No cash rent/other | 1,026 | 42.5 | 50.5 | 8.0 | 8.0 |
| Tenure | Owner/buyer | 51,275 | 72.2 | 79.3 | 7.1 | 7.1 |
| Tenure | Renter | 17,141 | 42.8 | 53.7 | 10.9 | 10.9 |
