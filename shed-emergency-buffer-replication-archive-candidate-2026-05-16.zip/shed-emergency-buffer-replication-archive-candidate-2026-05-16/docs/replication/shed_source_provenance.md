# SHED Source Provenance

Generated/verified: 2026-05-15

This table records official Federal Reserve SHED CSV/codebook URLs, local cached ZIP hashes when available, and known revision notes from the official SHED Data page. It is a replication scaffold for the emergency-buffer measurement note.

| Year | CSV HEAD | Local SHA-256 | Codebook HEAD | Data updated | Codebook updated | Notes |
|---:|---:|---|---:|---|---|---|
| 2013 | 200 | `7fd445e3e077…` | 200 | February 9, 2026 | July 29, 2022 | Official CSV URL uses SHED_data_2013_(CSV).zip; July 29, 2022 race-variable/codebook update; February 9, 2026 CSV/identifier update note. |
| 2014 | 200 | `dd69eb657465…` | 200 | February 9, 2026 | July 29, 2022 | Public datafile/codebook updated with occupation/industry changes; July 29, 2022 race-variable/codebook update; February 9, 2026 CSV/identifier update note. |
| 2015 | 200 | `4c05bd7e6fb1…` | 200 | February 9, 2026 | July 29, 2022 | July 29, 2022 race-variable/codebook update; February 9, 2026 CSV/identifier update note. |
| 2016 | 200 | `75df2095ed95…` | 200 | February 9, 2026 | July 29, 2022 | July 29, 2022 race-variable/codebook update; February 9, 2026 CSV/identifier update note. |
| 2017 | 200 | `33961cb6343e…` | 200 | February 9, 2026 | July 29, 2022 | July 29, 2022 race-variable/codebook update; February 9, 2026 CSV/identifier update note. |
| 2018 | 200 | `9399b67073ee…` | 200 | February 9, 2026 | July 29, 2022 | State identifiers and prior-year case IDs added in updates; July 29, 2022 race-variable/codebook update; February 9, 2026 CSV/identifier update note. |
| 2019 | 200 | `9c7b900d800d…` | 200 | February 9, 2026 | July 29, 2022 | December 8, 2020 prior-year case IDs added; July 29, 2022 race-variable/codebook update; February 9, 2026 CSV/identifier update note. |
| 2020 | 200 | `bd2837a7eef8…` | 200 | February 9, 2026 | August 31, 2023 | August 31, 2023 codebook update changed GE2_a wording; February 9, 2026 CSV/identifier update note. |
| 2021 | 200 | `929b51107aac…` | 200 | February 9, 2026 | May 23, 2022 | CSV files remain available after February 9, 2026 SAS discontinuation/identifier update note. |
| 2022 | 200 | `304528910345…` | 200 | February 9, 2026 | May 22, 2023 | CSV files remain available after February 9, 2026 SAS discontinuation/identifier update note. |
| 2023 | 200 | `8467284631ad…` | 200 | February 9, 2026 | October 7, 2024 | October 7, 2024 update corrected D41_b tabulations/missing values; February 9, 2026 CSV/identifier update note. |
| 2024 | 200 | `b455d02356a0…` | 200 | February 9, 2026 | May 28, 2025 | CSV files remain available after February 9, 2026 SAS discontinuation/identifier update note. |
| 2025 | 200 | `947215981dd9…` | 200 | May 13, 2026 | May 13, 2026 |  |
