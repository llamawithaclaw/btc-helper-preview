# SHED pay_casheqv Component Bridge

Direct measure: `pay_casheqv`. Component rule: `EF3_a` credit-card-paid-in-full OR `EF3_c` checking/savings/cash. False positive means component rule = 1 while direct `pay_casheqv` = 0.

| Year | N | Direct % | Component % | Diff pp | Agreement % | False positive % | False negative % |
|---|---:|---:|---:|---:|---:|---:|---:|
| 2020 | 11,648 | 64.6 | 72.2 | 7.6 | 92.4 | 7.6 | 0.0 |
| 2021 | 11,874 | 67.7 | 75.6 | 7.9 | 92.1 | 7.9 | 0.0 |
| 2022 | 9,293 | 63.2 | 70.7 | 7.5 | 92.5 | 7.5 | 0.0 |
| 2023 | 11,400 | 63.3 | 71.7 | 8.4 | 91.6 | 8.4 | 0.0 |
| 2024 | 12,295 | 62.7 | 71.3 | 8.6 | 91.4 | 8.6 | 0.0 |
| 2025 | 12,934 | 63.1 | 71.7 | 8.5 | 91.4 | 8.6 | 0.0 |
| 2020-2025 pooled | 69,444 | 64.1 | 72.3 | 8.1 | 91.9 | 8.1 | 0.0 |
