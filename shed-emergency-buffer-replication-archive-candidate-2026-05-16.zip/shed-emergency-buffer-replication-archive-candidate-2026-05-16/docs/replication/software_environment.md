# Software Environment

- Python: `3.14.3`
- Platform: `Linux-6.17.0-23-generic-x86_64-with-glibc2.39`
- Python executable: `python3.14`

The table-building scripts are designed to be local-first. Existing adjusted-model scripts use `numpy`; the replication-hardening script itself uses the Python standard library.
