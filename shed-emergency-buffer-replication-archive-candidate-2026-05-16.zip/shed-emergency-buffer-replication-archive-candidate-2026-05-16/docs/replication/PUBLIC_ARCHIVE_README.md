# SHED Emergency-Buffer Public Replication Archive README

## Purpose

This is the public replication archive scaffold for the BTC Helper / Sound Money Research SHED emergency-buffer work. Its purpose is to let a careful reader understand exactly what is reproducible, what files belong in a frozen public archive, what source data must be re-downloaded from the Federal Reserve, and what methodological limits remain.

This archive supports three public documents:

1. **Emergency Liquidity, Borrowing, and Hardship** — 2025 SHED microdata note.
2. **Emergency Buffers Over Time** — repeated-cross-section measurement note, 2015–2025.
3. **SHED Emergency-Buffer Measurement and Replication Note** — methodology / replication note.

## Public-data boundary

The archive is designed to be public. It should include code, documentation, generated aggregate tables, rendered papers, and checksums. It should not bundle raw SHED public-use ZIP files or person-level processed extracts by default.

Raw SHED public-use files are public Federal Reserve files, but the cleaner public archive posture is:

- document source URLs and local checksums;
- provide rebuild scripts;
- let users download/rebuild from official sources;
- avoid republishing full respondent-level files unless a later legal/source review explicitly approves it.

## Canonical source provenance

Use these files first:

- `shed_source_provenance.md`
- `shed_source_provenance.csv`
- `shed_source_provenance.json`

They document official Federal Reserve SHED CSV/codebook URLs, HEAD checks, local cached ZIP hashes where present, and known source-page revision notes.

## One-command rebuild

Run from the repository root:

```bash
python3 projects/sound-money-research/papers/paper-xi-shed-microdata/scripts/run_shed_replication_package.py
```

The wrapper runs:

1. `build_shed_replication_provenance.py`
2. `build_shed_overlap_bridge.py`
3. `build_shed_harmonized_panel.py`
4. `build_shed_replication_hardening.py`
5. `export_shed_replication_methodology.py`

Successful completion rebuilds the source provenance files, bridge diagnostics, harmonized panel outputs, replication-hardening tables, and rendered methodology export.

## Public archive manifest

Use the manifest files to freeze and audit an archive release:

- `shed_public_archive_manifest.md`
- `shed_public_archive_manifest.csv`
- `shed_public_archive_manifest.json`

The manifest records public archive candidates, file roles, byte sizes, SHA-256 checksums, and inclusion notes.

## Codebook / variable documentation

Use these files for variable interpretation:

- `SHED_REPLICATION_CODEBOOK_APPENDIX.md`
- `shed_replication_variable_map.md`
- `shed_replication_variable_map.csv`
- `shed_replication_raw_variable_presence.csv`

The central measurement warning is that `pay_casheqv` is the direct/official-aligned cash-equivalent variable in recent SHED microdata, while pre-2020 component rules based on `EF3_a` and `EF3_c` are diagnostic only and should not be treated as equivalent to the Federal Reserve official cash/equivalent benchmark.

## Core benchmark and bridge diagnostics

Use these files to understand the measurement boundary:

- `shed_official_topline_reproduction.md`
- `shed_official_topline_reproduction.csv`
- `shed_pay_casheqv_component_bridge.md`
- `shed_pay_casheqv_component_bridge.json`
- `shed_bridge_by_year_group_alternatives.md`
- `shed_bridge_by_year_group_alternatives.csv`

The key result is methodological, not promotional: simple component-built cash-equivalent rules overstate the official/direct cash-equivalent measure in overlap years, so they are useful diagnostics but not final trend substitutes.

## What is reproducible now

The current package supports reproducibility of:

- source provenance and local raw ZIP checksums;
- raw-variable presence by year;
- official cash/equivalent top-line benchmark comparison;
- 2020–2025 direct-vs-component bridge diagnostics;
- 2015–2025 repeated-cross-section harmonized measurement tables;
- 2021–2025 descriptive heterogeneity and approximate adjusted models;
- methodology note HTML/PDF export.

## What remains non-final

The package is strong enough for public transparency, but it is not a final journal replication archive. Remaining upgrades:

1. Exact codebook question text extraction for every wave and every variable.
2. Survey-design variance if sufficient public design information is available.
3. A frozen external release bundle with version tag and clean-room rebuild test.
4. Optional public packaging that separates source, generated outputs, and large local data.

## Trust rule

When describing this archive publicly, call it a **public replication scaffold** or **methodology archive candidate**, not a final certified replication package.
