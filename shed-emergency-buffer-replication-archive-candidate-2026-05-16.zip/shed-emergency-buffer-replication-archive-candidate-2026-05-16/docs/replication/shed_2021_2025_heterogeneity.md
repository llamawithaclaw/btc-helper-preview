# SHED 2021–2025 Heterogeneity Checks

Weighted descriptive subgroup checks for the replication package. Low buffer means lacking both $400 cash/equivalent capacity and three-month emergency savings. These are repeated-cross-section associations, not causal estimates.

| Group type | Group | N | Low both buffers % | Financially vulnerable % | Bill pressure % |
|---|---|---|---|---|---|
| Income | $100,000 or more | 21,940 | 8.9 | 7.5 | 8.2 |
| Income | $25,000-$49,999 | 9,783 | 41.9 | 41.1 | 29.7 |
| Income | $50,000-$99,999 | 16,274 | 25.1 | 23.4 | 17.0 |
| Income | Less than $25,000 | 12,171 | 58.1 | 49.2 | 39.9 |
| Housing tenure | No cash rent/other | 898 | 50.7 | 45.4 | 35.9 |
| Housing tenure | Owner/buyer | 44,418 | 21.6 | 19.4 | 14.9 |
| Housing tenure | Renter | 14,852 | 49.6 | 44.2 | 32.8 |
| Age | 18-29 | 9,137 | 41.2 | 32.5 | 28.1 |
| Age | 30-44 | 13,585 | 35.4 | 31.1 | 24.4 |
| Age | 45-59 | 14,278 | 29.2 | 27.4 | 19.3 |
| Age | 60+ | 23,168 | 16.5 | 17.2 | 11.3 |
| Children in household | No | 44,605 | 25.8 | 23.4 | 16.8 |
| Children in household | Yes | 15,563 | 37.7 | 33.1 | 27.4 |
