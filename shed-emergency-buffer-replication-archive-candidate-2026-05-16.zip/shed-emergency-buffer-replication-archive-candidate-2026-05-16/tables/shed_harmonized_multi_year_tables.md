# SHED Harmonized Multi-Year Tables

## Table 1. Annual weighted rates with official benchmark

Official cash/equiv $400 is the Federal Reserve published SHED report series. Constructed cash/equiv is derived from microdata component responses and is shown only as a diagnostic, not as the same object.

| Year | Official cash/equiv $400 | Constructed/direct diagnostic | Card over time | Unable $400 now | Three-month savings | Doing okay | Financially vulnerable |
|---:|---:|---:|---:|---:|---:|---:|---:|
| 2015 | 54.0 | 66.0 | 17.4 | 13.9 | 48.1 | 68.6 | 31.4 |
| 2016 | 56.0 | 68.7 | 20.0 | 12.1 | 48.7 | 70.0 | 30.0 |
| 2017 | 59.0 | 71.6 | 17.9 | 12.0 | 50.5 | 73.7 | 26.3 |
| 2018 | 61.0 | 69.1 | 15.6 | 12.4 | 51.6 | 74.9 | 25.1 |
| 2019 | 63.0 | 72.0 | 15.8 | 12.6 | 53.3 | 75.4 | 24.6 |
| 2020 | 64.0 | 64.6 | 15.6 | 12.6 | 55.4 | 75.1 | 24.9 |
| 2021 | 68.0 | 67.7 | 13.9 | 10.8 | 59.1 | 77.7 | 22.3 |
| 2022 | 63.0 | 65.0 | 15.8 | 13.1 | 54.1 | 73.1 | 26.9 |
| 2023 | 63.0 | 63.3 | 15.6 | 12.8 | 53.8 | 72.2 | 27.8 |
| 2024 | 63.0 | 62.7 | 15.2 | 13.0 | 55.0 | 72.9 | 27.1 |
| 2025 | 63.0 | 63.1 | 15.3 | 12.2 | 54.8 | 72.9 | 27.1 |

## Table A1. Official benchmark vs constructed/direct diagnostic

| Year | Official % | Constructed/direct diagnostic % | Difference (pp) |
|---:|---:|---:|---:|
| 2015 | 54.0 | 66.0 | 12.0 |
| 2016 | 56.0 | 68.7 | 12.7 |
| 2017 | 59.0 | 71.6 | 12.6 |
| 2018 | 61.0 | 69.1 | 8.1 |
| 2019 | 63.0 | 72.0 | 9.0 |
| 2020 | 64.0 | 64.6 | 0.6 |
| 2021 | 68.0 | 67.7 | -0.3 |
| 2022 | 63.0 | 65.0 | 2.0 |
| 2023 | 63.0 | 63.3 | 0.3 |
| 2024 | 63.0 | 62.7 | -0.3 |
| 2025 | 63.0 | 63.1 | 0.1 |

## Table 2. 2020–2025 cash/equivalent cross-tabs

| Group | Outcome | N | Weighted rate (%) | 95% CI (%) |
|---|---|---:|---:|---:|
| `cash_equiv_400=0` | `doing_okay` | 23,432 | 44.2 | 43.5–44.9 |
| `cash_equiv_400=1` | `doing_okay` | 48,386 | 90.4 | 90.1–90.7 |
| `cash_equiv_400=0` | `financially_vulnerable` | 23,432 | 55.8 | 55.1–56.5 |
| `cash_equiv_400=1` | `financially_vulnerable` | 48,386 | 9.6 | 9.3–9.9 |
| `cash_equiv_400=0` | `unable_pay_400_now` | 23,432 | 34.5 | 33.9–35.2 |
| `cash_equiv_400=1` | `unable_pay_400_now` | 48,386 | 0.2 | 0.2–0.2 |
| `cash_equiv_400=0` | `bill_pressure` | 12,640 | 41.6 | 40.6–42.5 |
| `cash_equiv_400=1` | `bill_pressure` | 23,989 | 7.2 | 6.8–7.6 |

## Table 3. 2021–2025 adjusted low-buffer associations

Mechanical $400 inability outcomes are diagnostic only because they overlap with the $400 emergency-response item.

| Outcome | N | Low-buffer coefficient (pp) | SE (pp) | 95% CI (pp) |
|---|---:|---:|---:|---:|
| `financially_vulnerable` | 60,168 | 37.7 | 0.5 | 36.7–38.8 |
| `unable_pay_400_now` | 60,168 | 29.0 | 0.4 | 28.2–29.9 |
| `bill_pressure` | 36,627 | 25.3 | 0.6 | 24.0–26.5 |
