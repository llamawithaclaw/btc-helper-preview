# SHED 2013–2025 Harmonization Manifest

| Year | Status | Fields | Cash $400 | 3mo savings | Card over time | Unable $400 | At least okay | Bill pressure vars | Core covariates |
|---:|---|---:|---|---|---|---|---|---|---|
| 2013 | missing | 0 |  |  |  |  |  |  | 0/7 |
| 2014 | ok | 321 |  |  |  |  |  |  | 3/7 |
| 2015 | ok | 398 |  | EF1 | EF3_b | EF3_h |  |  | 4/7 |
| 2016 | ok | 473 |  | EF1 | EF3_b | EF3_h |  |  | 4/7 |
| 2017 | ok | 447 |  | EF1 | EF3_b | EF3_h |  |  | 4/7 |
| 2018 | ok | 382 |  | EF1 | EF3_b | EF3_h |  |  | 4/7 |
| 2019 | ok | 325 |  | EF1 | EF3_b | EF3_h |  |  | 4/7 |
| 2020 | ok | 371 | pay_casheqv | EF1 | EF3_b | EF3_h | atleast_okay |  | 5/7 |
| 2021 | ok | 772 | pay_casheqv | EF1 | EF3_b | EF3_h | atleast_okay |  | 7/7 |
| 2022 | ok | 727 | pay_casheqv | EF1 | EF3_b | EF3_h | atleast_okay |  | 7/7 |
| 2023 | ok | 593 | pay_casheqv | EF1 | EF3_b | EF3_h | atleast_okay | EF5C | 7/7 |
| 2024 | ok | 751 | pay_casheqv | EF1 | EF3_b | EF3_h | atleast_okay | EF5C | 7/7 |
| 2025 | ok | 816 | pay_casheqv | EF1 | EF3_b | EF3_h | atleast_okay | EF5C/EF5D | 7/7 |
