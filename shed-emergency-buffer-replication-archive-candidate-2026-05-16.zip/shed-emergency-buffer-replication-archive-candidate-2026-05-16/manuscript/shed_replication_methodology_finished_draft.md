# SHED Emergency-Buffer Measurement and Replication Note

## Source Provenance, Harmonization Limits, and Reproducibility Package for Emergency-Liquidity Measures

**Author:** Arne Kotte  
**Date:** May 2026  
**Document type:** Data and replication-methodology note / revised draft

## Abstract

Survey-based measures of household emergency liquidity are sensitive to instrument wording, response construction, and public-use harmonization. This note documents a replication package for Federal Reserve Survey of Household Economics and Decisionmaking (SHED) emergency-buffer measures and corrects a material harmonization error in a prior draft. A pre-2020 component-built measure of the ability to cover a $400 emergency expense with cash or its equivalent does not reproduce the Federal Reserve's official published trend. The official series rises from 54 percent in 2015 to 68 percent in 2021 and then returns to about 63 percent in 2022–2025; the component-built diagnostic is 8–13 percentage points higher before 2020. In overlap years, 2020–2025, the broad component rule `EF3_a OR EF3_c` is 8.1 percentage points above direct `pay_casheqv`, with similar gaps by year and larger errors for younger, lower-income, and renter groups. The note therefore treats the official series as the benchmark, uses direct respondent-level cash/equivalent evidence from 2020 onward, and labels pre-2020 component measures as diagnostics. The contribution is methodological: a transparent source, variable, bridge, and reproducibility framework for future substantive work on household liquidity and financial fragility.

## 1. Research question and contribution

How sensitive are measured emergency-liquidity trends to survey-instrument harmonization? This question matters because emergency-buffer measures are commonly used to describe household financial fragility, but small differences in response construction can change the level, timing, and subgroup interpretation of the trend.

This note studies one concrete case: the SHED measure of whether an adult would cover a $400 emergency expense completely using cash or its equivalent. A prior draft treated a pre-2020 component-built public-use microdata measure as continuous with the Federal Reserve's official published cash/equivalent series. That was wrong. The constructed measure did not reproduce the official trend. The corrected package now separates three objects that must not be blurred:

1. **Official published top-lines** from Federal Reserve SHED reports.
2. **Direct public-use microdata measures**, especially `pay_casheqv` from 2020 onward.
3. **Author-constructed diagnostics**, especially pre-2020 component rules based on emergency-expense response options.

The contribution is not a causal estimate and not a stand-alone general-interest household-finance article. It is a data and replication note. Its purpose is to make later empirical work on emergency liquidity more credible by documenting source provenance, variable availability, official benchmarks, bridge tests, subgroup diagnostics, variance limits, and a reproducible rebuild workflow.

## 2. Data and construct definitions

SHED is the Federal Reserve's Survey of Household Economics and Decisionmaking, an annual survey of U.S. adults covering financial well-being, emergency expenses, credit, employment, housing, education, and related household-finance topics. The replication package uses public-use SHED CSV files and codebooks for 2013–2025, but the main emergency-buffer measurement note begins in 2015 because the inspected core emergency-expense variables appear from 2015 onward.

All estimates are adult-level weighted repeated-cross-section estimates. They are not a household panel and do not estimate within-person transitions. The current scripts use final respondent weights. In pooled descriptive work, years are pooled as repeated cross sections; adjusted models include year indicators where used.

The package tracks six construct groups:

| Construct | Raw variables | Usable window | Denominator and coding | Key caveat |
|---|---|---|---|---|
| Cash/equivalent $400 capacity | `pay_casheqv`; `EF3_a`; `EF3_c` | Official benchmark 2015–2025; direct microdata `pay_casheqv` 2020–2025; pre-2020 component diagnostic only | Adults with valid emergency-expense response and positive final weight. Yes=1, No=0. | Pre-2020 component construction overstates the official series by 8–13 percentage points and is not equivalent. |
| Three-month emergency savings | `EF1` | 2015–2025 trend; richer adjusted work mainly 2021–2025 | Adults with valid rainy-day/emergency-savings response and positive final weight. Yes=1, No=0. | Repeated cross-section, not within-person savings accumulation. |
| Financially vulnerable / doing okay | `B2`; `atleast_okay` | Broad `B2`-derived coding; direct `atleast_okay` from 2020 onward | Doing okay=1 for living comfortably or doing okay; financially vulnerable=1 for just getting by or finding it difficult. | Subjective financial status, not a balance-sheet measure. |
| Bill pressure | `EF5C`; `EF5D` | Use cautiously, mainly 2021–2025 | Adults with valid bill-pressure response and positive final weight. | Not comparable enough for a 2015–2025 headline trend. |
| Card paid over time for $400 emergency | `EF3_b` | 2015–2025 descriptive series | Selected option=1, no/not selected=0. | Not cash-equivalent; should not be merged with `pay_casheqv`. |
| Covariates | income, age, education, race/ethnicity, tenure, employment, children, region fields | Richest adjusted-analysis coverage 2021–2025 | Collapsed public-use categories with non-missing construct, outcome, covariates, and positive final weight. | Public-use categories are coarse; adjusted models are descriptive only. |

Exact annual question wording, response options, and skip patterns still need to be extracted into a formal codebook appendix before this package becomes a final public archive. The current variable map is a finished draft of the harmonization boundary, not a substitute for annual codebook text.

## 3. Source provenance and reproducibility architecture

The replication package records official Federal Reserve source URLs for SHED public-use CSV files and codebooks from 2013 through 2025. It also records local cached ZIP hashes where available, source update dates, and known revision notes. This matters because several SHED files have been updated or reissued over time, including race-variable/codebook updates and CSV/identifier updates. The workflow also handles the distinct official 2013 CSV URL pattern.

The core package is organized into raw public files, processed data, tables, replication documentation, manuscripts, exports, and scripts. The main generated artifacts are:

- `shed_source_provenance.md` / `.csv` / `.json` for official URLs, codebooks, hashes, and update notes;
- `shed_replication_variable_map.md` / `.csv` for construct definitions, raw variables, usable windows, and caveats;
- `shed_official_topline_reproduction.md` / `.csv` for the official cash/equivalent benchmark versus microdata diagnostics;
- `shed_pay_casheqv_component_bridge.md` and `shed_bridge_by_year_group_alternatives.md` for overlap bridge tests;
- `shed_2021_2025_heterogeneity.md` / `.csv` for subgroup checks;
- `shed_variance_strategy.md` for uncertainty limits; and
- `software_environment.md` / `.json` for local runtime capture.

The current one-command wrapper, `run_shed_replication_package.py`, rebuilds source provenance, bridge diagnostics, harmonized repeated-cross-section tables, replication-hardening tables, and manuscript exports. The package is reproducible locally from the project directory, but it is not yet a frozen external archive. A final public release should remove local-path assumptions, add dependency locking or a container, record expected run time, and publish checksums for final outputs.

## 4. Official-topline benchmark

The central benchmark is the Federal Reserve published SHED series for adults who would cover a $400 emergency expense completely using cash or its equivalent. The official trend is 54, 56, 59, 61, 63, 64, 68, 63, 63, 63, and 63 percent for 2015–2025. The high point is 2021, not 2019.

| Year | Official % | Microdata diagnostic % | Difference, percentage points | Status |
|---:|---:|---:|---:|---|
| 2015 | 54.0 | 66.0 | 12.0 | Component diagnostic not equivalent |
| 2016 | 56.0 | 68.7 | 12.7 | Component diagnostic not equivalent |
| 2017 | 59.0 | 71.6 | 12.6 | Component diagnostic not equivalent |
| 2018 | 61.0 | 69.1 | 8.1 | Component diagnostic not equivalent |
| 2019 | 63.0 | 72.0 | 9.0 | Component diagnostic not equivalent |
| 2020 | 64.0 | 64.6 | 0.6 | Direct/near-direct validation window |
| 2021 | 68.0 | 67.7 | -0.3 | Direct/near-direct validation window |
| 2022 | 63.0 | 65.0 | 2.0 | Direct/near-direct validation window |
| 2023 | 63.0 | 63.3 | 0.3 | Direct/near-direct validation window |
| 2024 | 63.0 | 62.7 | -0.3 | Direct/near-direct validation window |
| 2025 | 63.0 | 63.1 | 0.1 | Direct/near-direct validation window |

This table changes the interpretation of the emergency-buffer trend. The earlier component-built diagnostic suggested a 2019 high. The official series shows a 2021 high. The difference is not rounding noise. It is a construct problem.

The 2022 diagnostic is 2.0 percentage points above the official benchmark, larger than the other post-2020 differences. This likely reflects a combination of denominator, weighting, missingness, and public-use coding differences between the author's reconstruction and the Federal Reserve's published reporting sample. The difference is small relative to the pre-2020 gap, but it is large enough that future benchmark reproduction should document denominators and official report samples explicitly.

## 5. Bridge diagnostics and alternative rules

The bridge diagnostic compares direct `pay_casheqv` with the broad component rule `EF3_a OR EF3_c` in 2020–2025, where both can be observed. `EF3_a` captures putting the $400 expense on a credit card and paying it off in full at the next statement; `EF3_c` captures using money currently in checking, savings, or cash. The broad rule is consistently too high.

| Year | N | Direct `pay_casheqv` % | OR rule % | Difference, percentage points | Cash-only % | Card-full-only % | AND rule % | False positive % |
|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| 2020 | 11,648 | 64.6 | 72.2 | 7.6 | 45.1 | 36.1 | 8.9 | 7.6 |
| 2021 | 11,874 | 67.7 | 75.6 | 7.9 | 48.4 | 37.4 | 10.2 | 7.9 |
| 2022 | 9,293 | 63.2 | 70.7 | 7.5 | 43.8 | 35.5 | 8.6 | 7.5 |
| 2023 | 11,400 | 63.3 | 71.7 | 8.4 | 45.0 | 36.9 | 10.2 | 8.4 |
| 2024 | 12,295 | 62.7 | 71.3 | 8.6 | 42.5 | 37.9 | 9.2 | 8.6 |
| 2025 | 12,934 | 63.1 | 71.7 | 8.5 | 43.2 | 38.4 | 9.9 | 8.6 |

The annual evidence shows that the pooled 8.1 percentage-point gap is not driven by a single year. It is stable across the direct-measure window. Alternative simple rules do not solve the problem: cash-only and card-full-only rules are too narrow for the official construct, while the AND rule is much too restrictive. The broad OR rule is intuitively appealing but over-classifies cash/equivalent capacity.

The error is also heterogeneous across groups:

| Group type | Group | N | Direct % | OR rule % | Difference, percentage points | False positive % |
|---|---|---:|---:|---:|---:|---:|
| Income | Less than $25,000 | 14,350 | 34.0 | 44.1 | 10.1 | 10.1 |
| Income | $25,000–$49,999 | 11,520 | 50.6 | 61.0 | 10.4 | 10.4 |
| Income | $50,000–$99,999 | 18,750 | 68.5 | 77.3 | 8.9 | 8.9 |
| Income | $100,000 or more | 24,717 | 86.9 | 92.2 | 5.3 | 5.3 |
| Age | 18–29 | 10,911 | 51.4 | 64.0 | 12.6 | 12.6 |
| Age | 30–44 | 15,535 | 57.6 | 66.8 | 9.2 | 9.2 |
| Age | 45–59 | 16,523 | 64.6 | 71.7 | 7.1 | 7.1 |
| Age | 60+ | 26,473 | 77.6 | 82.6 | 5.0 | 5.0 |
| Tenure | Renter | 17,141 | 42.8 | 53.7 | 10.9 | 10.9 |
| Tenure | Owner/buyer | 51,275 | 72.2 | 79.3 | 7.1 | 7.1 |

The subgroup bridge is important. The broad component rule does not merely shift the level upward; it does so more among groups that are already central to financial-fragility analysis, especially younger adults, renters, and lower-income respondents. That means pre-2020 subgroup trends based on the broad component rule would risk biased comparisons, not just a harmless level difference.

## 6. Heterogeneity checks after respecting the measurement boundary

Once the cash/equivalent boundary is corrected, the cleanest respondent-level direct-measure window begins in 2020. The richest covariate window begins in 2021. The package therefore reports 2021–2025 heterogeneity checks for low-buffer status, defined as lacking both $400 cash/equivalent capacity and three-month emergency savings. These estimates are pooled adult-level repeated-cross-section estimates using final respondent weights. They are descriptive and noncausal.

| Group type | Group | N | Low both buffers % | Financially vulnerable % | Bill pressure % |
|---|---|---:|---:|---:|---:|
| Income | Less than $25,000 | 12,171 | 58.1 | 49.2 | 39.9 |
| Income | $25,000–$49,999 | 9,783 | 41.9 | 41.1 | 29.7 |
| Income | $50,000–$99,999 | 16,274 | 25.1 | 23.4 | 17.0 |
| Income | $100,000 or more | 21,940 | 8.9 | 7.5 | 8.2 |
| Housing tenure | Renter | 14,852 | 49.6 | 44.2 | 32.8 |
| Housing tenure | Owner/buyer | 44,418 | 21.6 | 19.4 | 14.9 |
| Age | 18–29 | 9,137 | 41.2 | 32.5 | 28.1 |
| Age | 30–44 | 13,585 | 35.4 | 31.1 | 24.4 |
| Age | 45–59 | 14,278 | 29.2 | 27.4 | 19.3 |
| Age | 60+ | 23,168 | 16.5 | 17.2 | 11.3 |
| Children | No | 44,605 | 25.8 | 23.4 | 16.8 |
| Children | Yes | 15,563 | 37.7 | 33.1 | 27.4 |

The pattern is coherent but should be read carefully. Low-buffer exposure is higher among lower-income adults, renters, younger adults, and adults with children. That does not prove that emergency buffers cause lower hardship. It shows that emergency-buffer weakness is concentrated along household margins that are relevant for later models of liquidity, borrowing, bill pressure, and hardship.

The full replication file also includes employment and race/ethnicity checks where sample sizes are adequate. They are not emphasized in the main table because the current draft has not yet added the exact annual codebook appendix needed to make all public-use category changes transparent.

## 7. Inference and uncertainty

The current package reports approximate weighted confidence intervals. Weighted proportions use final respondent weights and approximate effective sample size as `(sum w)^2 / sum(w^2)`. Adjusted descriptive models use weighted linear probability models with year indicators and observed covariates where used.

This strategy is acceptable for a public measurement note, but it is not a final publication-grade survey-design solution. Three forms of uncertainty should be distinguished:

1. **Sampling uncertainty:** ordinary sampling variation in weighted survey estimates.
2. **Survey-design uncertainty:** uncertainty that should ideally be estimated using the survey's recommended design information, replicate weights, strata, or primary sampling units where available.
3. **Construct-harmonization uncertainty:** uncertainty created by changing survey variables, response options, derived variables, denominators, and public-use coding across waves.

For this note, construct-harmonization uncertainty is the central issue. The 8–13 percentage-point pre-2020 cash/equivalent discrepancy is far larger than conventional sampling-error adjustments would plausibly explain. Still, a final empirical article should implement the appropriate SHED survey-design variance method if the needed design variables are available, or provide a formal explanation of why final-weight/Kish approximations are the best available public-use option.

## 8. What the corrected measurement supports

After the correction, three claims survive.

First, the official SHED trend says cash/equivalent $400 capacity rose from 54 percent in 2015 to 68 percent in 2021, then returned to about 63 percent in 2022–2025. The earlier 2019-high claim does not survive.

Second, direct 2020–2025 respondent-level comparisons remain useful. Adults without direct cash/equivalent $400 capacity report substantially worse financial well-being and more bill pressure than adults with such capacity. These comparisons are descriptive and should not be interpreted causally.

Third, 2021–2025 subgroup patterns show that low-buffer exposure is concentrated among lower-income adults, renters, younger adults, and adults with children. These patterns motivate substantive household-finance questions about liquidity, income risk, credit use, and hardship, but they do not answer those questions by themselves.

The corrected measurement does not support continuous pre-2020 respondent-level subgroup trends using the broad component rule as if it were `pay_casheqv`. It also does not support a causal claim that emergency buffers independently reduce hardship. Those claims require stronger design.

## 9. Reproducibility status and remaining archive work

The current workflow is locally reproducible through `scripts/run_shed_replication_package.py`. The wrapper rebuilds source provenance, overlap bridges, harmonized repeated-cross-section tables, replication-hardening outputs, and manuscript exports.

Before the package should be treated as a final public archive, six tasks remain:

1. extract exact annual question text, response options, universes, and skip patterns into a codebook appendix;
2. reproduce all official SHED top-lines used in the substantive papers, not only the $400 cash/equivalent series;
3. document denominators and missing-value handling for every percentage in the benchmark, bridge, and heterogeneity tables;
4. implement survey-design variance or publish a formal approximation rationale;
5. add dependency locking, expected run time, output checksums, and a clean fresh-checkout run instruction; and
6. remove local-path assumptions from the release package.

Listing these tasks is not a substitute for doing them. It is a boundary statement: the current document is a finished data/methodology draft and replication scaffold, not a frozen archive.

## 10. Conclusion

The corrected SHED emergency-buffer work teaches a narrow but important lesson: emergency-liquidity trends can change materially when a constructed survey response is treated as equivalent to an official derived measure without validation. In this case, the pre-2020 component-built cash/equivalent diagnostic is 8–13 percentage points above the official Federal Reserve series, and the overlap bridge shows why. The broad component rule over-classifies cash/equivalent capacity even in years where direct `pay_casheqv` is observable.

The defensible empirical path is therefore narrower and stronger. Use the official published series for 2015–2025 trend claims. Use direct public-use `pay_casheqv` for respondent-level cash/equivalent analysis from 2020 onward. Treat pre-2020 component rules as diagnostics unless a bridge design can reproduce the official benchmark. With those boundaries in place, the SHED files remain valuable for studying household emergency liquidity, financial vulnerability, bill pressure, and subgroup exposure.

This note is best read as a replication appendix, data note, or methodological supplement to a substantive household-finance paper. Its value is that it prevents a plausible but wrong harmonization shortcut from contaminating later empirical work.

## References and source notes

Board of Governors of the Federal Reserve System. *Survey of Household Economics and Decisionmaking* public-use data files and codebooks, 2013–2025.

Board of Governors of the Federal Reserve System. Annual *Economic Well-Being of U.S. Households* reports, 2015–2025.

Lusardi, Annamaria, Daniel J. Schneider, and Peter Tufano. 2011. “Financially Fragile Households: Evidence and Implications.” *Brookings Papers on Economic Activity*.

Kaplan, Greg, Giovanni L. Violante, and Justin Weidner. 2014. “The Wealthy Hand-to-Mouth.” *Brookings Papers on Economic Activity*.

Gross, David B., and Nicholas S. Souleles. 2002. “Do Liquidity Constraints and Interest Rates Matter for Consumer Behavior? Evidence from Credit Card Data.” *Quarterly Journal of Economics*.

Sullivan, James X. 2008. “Borrowing During Unemployment: Unsecured Debt as a Safety Net.” *Journal of Human Resources*.

## Data and replication note

All scripts and generated artifacts are local to `projects/sound-money-research/papers/paper-xi-shed-microdata/`. The revised methodology draft uses Federal Reserve SHED public-use files, official published SHED top-line values for the $400 cash/equivalent benchmark, and locally generated CSV/Markdown tables. The current package is public-data-first, descriptive, and noncausal. It contains no private accumulation-engine model inputs and no investment recommendation.
