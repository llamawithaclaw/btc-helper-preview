#!/usr/bin/env python3
"""Build SHED source provenance tables for the emergency-buffer replication package.

This is intentionally a provenance scaffold, not a statistical analysis script.
It records official Federal Reserve SHED data/codebook URLs, last-updated notes,
local file hashes when present, and known revision notes from the official SHED
Data page as fetched/inspected in May 2026.
"""
from __future__ import annotations
import csv, hashlib, json
from pathlib import Path
from urllib.request import Request, urlopen

ROOT = Path(__file__).resolve().parents[1]
RAW = ROOT / 'data' / 'raw'
DOCS = ROOT / 'docs' / 'replication'
BASE = 'https://www.federalreserve.gov'
FETCH_DATE = '2026-05-15'
YEARS = range(2013, 2026)

LAST_UPDATED = {
    2025: {'codebook': 'May 13, 2026', 'data': 'May 13, 2026'},
    2024: {'codebook': 'May 28, 2025', 'data': 'February 9, 2026'},
    2023: {'codebook': 'October 7, 2024', 'data': 'February 9, 2026'},
    2022: {'codebook': 'May 22, 2023', 'data': 'February 9, 2026'},
    2021: {'codebook': 'May 23, 2022', 'data': 'February 9, 2026'},
    2020: {'codebook': 'August 31, 2023', 'data': 'February 9, 2026'},
    2019: {'codebook': 'July 29, 2022', 'data': 'February 9, 2026'},
    2018: {'codebook': 'July 29, 2022', 'data': 'February 9, 2026'},
    2017: {'codebook': 'July 29, 2022', 'data': 'February 9, 2026'},
    2016: {'codebook': 'July 29, 2022', 'data': 'February 9, 2026'},
    2015: {'codebook': 'July 29, 2022', 'data': 'February 9, 2026'},
    2014: {'codebook': 'July 29, 2022', 'data': 'February 9, 2026'},
    2013: {'codebook': 'July 29, 2022', 'data': 'February 9, 2026'},
}

REVISION_NOTES = {
    2025: '',
    2024: 'CSV files remain available after February 9, 2026 SAS discontinuation/identifier update note.',
    2023: 'October 7, 2024 update corrected D41_b tabulations/missing values; February 9, 2026 CSV/identifier update note.',
    2022: 'CSV files remain available after February 9, 2026 SAS discontinuation/identifier update note.',
    2021: 'CSV files remain available after February 9, 2026 SAS discontinuation/identifier update note.',
    2020: 'August 31, 2023 codebook update changed GE2_a wording; February 9, 2026 CSV/identifier update note.',
    2019: 'December 8, 2020 prior-year case IDs added; July 29, 2022 race-variable/codebook update; February 9, 2026 CSV/identifier update note.',
    2018: 'State identifiers and prior-year case IDs added in updates; July 29, 2022 race-variable/codebook update; February 9, 2026 CSV/identifier update note.',
    2017: 'July 29, 2022 race-variable/codebook update; February 9, 2026 CSV/identifier update note.',
    2016: 'July 29, 2022 race-variable/codebook update; February 9, 2026 CSV/identifier update note.',
    2015: 'July 29, 2022 race-variable/codebook update; February 9, 2026 CSV/identifier update note.',
    2014: 'Public datafile/codebook updated with occupation/industry changes; July 29, 2022 race-variable/codebook update; February 9, 2026 CSV/identifier update note.',
    2013: 'Official CSV URL uses SHED_data_2013_(CSV).zip; July 29, 2022 race-variable/codebook update; February 9, 2026 CSV/identifier update note.',
}


def codebook_url(year:int)->str:
    if year >= 2020:
        return f'{BASE}/consumerscommunities/files/SHED_{year}codebook.pdf'
    if year == 2019:
        return f'{BASE}/consumerscommunities/files/SHED-2019-codebook.pdf'
    prefix = 'SHED' if year in (2017, 2018) else 'shed'
    return f'{BASE}/consumerscommunities/files/{prefix}_{year}codebook.pdf'


def csv_url(year:int)->str:
    if year == 2013:
        return f'{BASE}/consumerscommunities/files/SHED_data_2013_(CSV).zip'
    return f'{BASE}/consumerscommunities/files/SHED_public_use_data_{year}_(CSV).zip'


def local_zip(year:int)->Path:
    return RAW / f'SHED_public_use_data_{year}_CSV.zip'


def sha256(path:Path)->str:
    h=hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda:f.read(1024*1024), b''):
            h.update(chunk)
    return h.hexdigest()


def head_status(url:str)->tuple[str,str]:
    try:
        req=Request(url, method='HEAD', headers={'User-Agent':'Mozilla/5.0 (compatible; SHED-provenance/1.0)'})
        with urlopen(req, timeout=20) as r:
            return str(r.status), r.headers.get('content-length','')
    except Exception as e:
        return f'ERR:{type(e).__name__}', ''


def write_csv(path, rows, headers):
    with path.open('w', newline='') as f:
        w=csv.DictWriter(f, fieldnames=headers)
        w.writeheader(); w.writerows(rows)


def main():
    DOCS.mkdir(parents=True, exist_ok=True)
    rows=[]
    for year in YEARS:
        z=local_zip(year)
        data_status, data_len = head_status(csv_url(year))
        code_status, code_len = head_status(codebook_url(year))
        rows.append({
            'year': year,
            'official_csv_url': csv_url(year),
            'official_csv_head_status': data_status,
            'official_csv_content_length': data_len,
            'local_zip_path': str(z.relative_to(ROOT)) if z.exists() else '',
            'local_zip_bytes': z.stat().st_size if z.exists() else '',
            'local_zip_sha256': sha256(z) if z.exists() else '',
            'codebook_url': codebook_url(year),
            'codebook_head_status': code_status,
            'codebook_content_length': code_len,
            'codebook_last_updated': LAST_UPDATED[year]['codebook'],
            'data_last_updated': LAST_UPDATED[year]['data'],
            'revision_notes': REVISION_NOTES[year],
            'fetched_or_verified_on': FETCH_DATE,
        })
    headers=list(rows[0].keys())
    write_csv(DOCS/'shed_source_provenance.csv', rows, headers)
    (DOCS/'shed_source_provenance.json').write_text(json.dumps(rows, indent=2))
    md=['# SHED Source Provenance', '', f'Generated/verified: {FETCH_DATE}', '', 'This table records official Federal Reserve SHED CSV/codebook URLs, local cached ZIP hashes when available, and known revision notes from the official SHED Data page. It is a replication scaffold for the emergency-buffer measurement note.', '', '| Year | CSV HEAD | Local SHA-256 | Codebook HEAD | Data updated | Codebook updated | Notes |', '|---:|---:|---|---:|---|---|---|']
    for r in rows:
        sha=(r['local_zip_sha256'][:12]+'…') if r['local_zip_sha256'] else ''
        md.append(f"| {r['year']} | {r['official_csv_head_status']} | `{sha}` | {r['codebook_head_status']} | {r['data_last_updated']} | {r['codebook_last_updated']} | {r['revision_notes']} |")
    (DOCS/'shed_source_provenance.md').write_text('\n'.join(md)+'\n')
    print(json.dumps({'rows':len(rows),'csv':str(DOCS/'shed_source_provenance.csv'),'md':str(DOCS/'shed_source_provenance.md')}, indent=2))

if __name__ == '__main__':
    main()
