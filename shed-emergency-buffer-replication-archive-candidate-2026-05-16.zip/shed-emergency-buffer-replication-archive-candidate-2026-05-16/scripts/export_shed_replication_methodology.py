#!/usr/bin/env python3
"""Export the SHED replication methodology draft to HTML and PDF."""
from __future__ import annotations
import html
import re
import subprocess
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
MD = ROOT / "manuscript" / "shed_replication_methodology_finished_draft.md"
EXPORTS = ROOT / "exports"
HTML = EXPORTS / "SHED_Emergency_Buffer_Replication_Methodology_Draft.html"
PDF = EXPORTS / "SHED_Emergency_Buffer_Replication_Methodology_Draft.pdf"
PLAYWRIGHT = (ROOT.parents[3] / "btc-helper-vnext" / "node_modules" / "playwright")
if not PLAYWRIGHT.exists():
    PLAYWRIGHT = Path("node_modules/playwright")


def inline(t: str) -> str:
    t = html.escape(t)
    t = re.sub(r"`([^`]+)`", r"<code>\1</code>", t)
    t = re.sub(r"\*\*([^*]+)\*\*", r"<strong>\1</strong>", t)
    t = re.sub(r"\*([^*]+)\*", r"<em>\1</em>", t)
    return t


def md_to_html(md: str) -> str:
    out, para, table = [], [], []
    ul = False

    def fp():
        nonlocal para
        if para:
            out.append("<p>" + inline(" ".join(para)) + "</p>")
            para = []

    def ful():
        nonlocal ul
        if ul:
            out.append("</ul>")
            ul = False

    def ft():
        nonlocal table
        if not table:
            return
        if len(table) >= 2 and re.match(r"^\s*\|?\s*:?-{3,}:?\s*(\|\s*:?-{3,}:?\s*)+\|?\s*$", table[1]):
            rows = []
            for i, row in enumerate(table):
                if i == 1:
                    continue
                rows.append([c.strip() for c in row.strip().strip("|").split("|")])
            out.append('<div class="table-wrap"><table><thead><tr>' + ''.join(f'<th>{inline(c)}</th>' for c in rows[0]) + '</tr></thead><tbody>')
            for row in rows[1:]:
                out.append('<tr>' + ''.join(f'<td>{inline(c)}</td>' for c in row) + '</tr>')
            out.append('</tbody></table></div>')
        else:
            for row in table:
                out.append('<p>' + inline(row) + '</p>')
        table = []

    def close():
        fp(); ful(); ft()

    for raw in md.splitlines():
        line = raw.rstrip()
        if not line.strip():
            close(); continue
        if "|" in line and re.match(r"^\s*\|?.+\|.+\|?\s*$", line):
            fp(); ful(); table.append(line); continue
        ft()
        if line.startswith("# "):
            close(); out.append(f"<h1>{inline(line[2:].strip())}</h1>"); continue
        if line.startswith("## "):
            close(); out.append(f"<h2>{inline(line[3:].strip())}</h2>"); continue
        if line.startswith("### "):
            close(); out.append(f"<h3>{inline(line[4:].strip())}</h3>"); continue
        if line.startswith("- "):
            fp()
            if not ul:
                out.append("<ul>"); ul = True
            out.append("<li>" + inline(line[2:].strip()) + "</li>"); continue
        para.append(line.strip())
    close()
    return "\n".join(out)


def write_html() -> None:
    EXPORTS.mkdir(parents=True, exist_ok=True)
    body = md_to_html(MD.read_text())
    cover = """<section class="cover"><div><div class="kicker">Replication methodology draft</div><h1>SHED Emergency-Buffer Replication Methodology</h1><p class="subtitle">Source Provenance, Harmonization Limits, and Reproducibility Package</p><p class="author">Arne Kotte</p></div><div class="meta"><div><strong>Document type</strong>Replication / methodology finished draft</div><div><strong>Series role</strong>Emergency-buffer empirical hardening</div><div><strong>Date</strong>May 2026</div></div></section>"""
    css = """@page{size:Letter;margin:.70in .64in}body{margin:0;background:#f6f2e8;color:#171814;font-family:Georgia,'Times New Roman',serif;line-height:1.46}main{max-width:8.5in;margin:0 auto;background:#fffdf6;padding:0 .2in .35in}.cover{min-height:8.55in;display:flex;flex-direction:column;justify-content:space-between;border-top:4px solid #536f80;padding:28px 0 10px;break-after:page}.kicker{font-family:Arial,sans-serif;text-transform:uppercase;letter-spacing:.12em;font-weight:800;color:#536f80;font-size:10pt;margin-bottom:16px}.cover h1{font-size:32pt;line-height:1.02;margin:0 0 12px;letter-spacing:-.035em}.subtitle{font-size:15pt;color:#5d6258;margin:0 0 18px}.author{font-size:13pt;font-weight:bold}.meta{display:grid;grid-template-columns:repeat(3,1fr);gap:10px;border-top:1px solid #d8d2c0;padding-top:14px;font-family:Arial,sans-serif;font-size:9.3pt;color:#5d6258}.meta strong{display:block;color:#161711;text-transform:uppercase;letter-spacing:.08em;font-size:7.5pt;margin-bottom:4px}h1,h2,h3{font-family:Arial,sans-serif;line-height:1.16;color:#111}h1{font-size:23pt;margin:0 0 10px}h2{font-size:15pt;margin:24px 0 8px;border-bottom:1px solid #d8d2c0;padding-bottom:4px;break-after:avoid}h3{font-size:12.2pt;margin:18px 0 6px}p{margin:0 0 8px;font-size:10.25pt}ul{margin:0 0 10px 20px;padding:0;font-size:10.05pt}li{margin:0 0 4px}.table-wrap{margin:9px 0 13px;break-inside:avoid}table{width:100%;border-collapse:collapse;font-family:Arial,sans-serif;font-size:7.7pt}th,td{border:1px solid #d8d2c0;padding:4.5px;vertical-align:top}th{background:#ece7d7;text-align:left;font-weight:800}td:nth-child(n+2),th:nth-child(n+2){text-align:right}td:first-child,th:first-child{text-align:left}code{font-family:'Courier New',monospace;font-size:.92em;background:#f1ecde;padding:0 2px;border-radius:2px}strong{font-weight:700}"""
    HTML.write_text(f"<!doctype html><html><head><meta charset='utf-8'><title>SHED Emergency-Buffer Replication Methodology</title><style>{css}</style></head><body><main>{cover}{body}</main></body></html>")


def write_pdf() -> None:
    node = f"""
const {{ chromium }} = require('{PLAYWRIGHT.as_posix()}');
(async () => {{
  const browser = await chromium.launch({{ headless: true }});
  const page = await browser.newPage();
  await page.goto('file://{HTML.resolve().as_posix()}', {{ waitUntil: 'load' }});
  await page.pdf({{ path: '{PDF.resolve().as_posix()}', format: 'Letter', printBackground: true, preferCSSPageSize: true }});
  await browser.close();
}})().catch(e => {{ console.error(e); process.exit(1); }});
"""
    subprocess.run(["node", "-e", node], check=True)


def main() -> None:
    write_html()
    write_pdf()
    print(HTML)
    print(PDF)


if __name__ == "__main__":
    main()
