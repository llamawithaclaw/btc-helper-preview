#!/usr/bin/env python3
"""Build SHED 2015-2025 harmonized emergency-buffer panel.

The script downloads/uses annual SHED public-use CSV ZIPs, harmonizes the
variables that are consistently interpretable, and writes trend, subgroup, and
adjusted-association tables for a finished multi-year descriptive draft.
"""
from __future__ import annotations
import csv, json, math, urllib.request, zipfile
from pathlib import Path
import numpy as np

ROOT = Path(__file__).resolve().parents[1]
RAW = ROOT / 'data' / 'raw'
PROCESSED = ROOT / 'data' / 'processed'
TABLES = ROOT / 'tables'
YEARS = list(range(2013, 2026))
BASE_URLS = [
    'https://www.federalreserve.gov/consumerscommunities/files/SHED_public_use_data_{year}_(CSV).zip',
    'https://www.federalreserve.gov/consumerscommunities/files/SHED_public_use_data_{year}.zip',
    'https://www.federalreserve.gov/consumerscommunities/files/SHED_data_{year}_(CSV).zip',
    'https://www.federalreserve.gov/consumerscommunities/files/SHED_data_{year}.zip',
]

# Federal Reserve published SHED report series for adults who would cover a
# $400 emergency expense completely using cash or its equivalent. Used as the
# benchmark series after referee review; pre-2020 component constructions are
# not treated as equivalent to this official measure.
FED_OFFICIAL_CASH_EQUIV_400 = {
    2015: 0.54, 2016: 0.56, 2017: 0.59, 2018: 0.61, 2019: 0.63,
    2020: 0.64, 2021: 0.68, 2022: 0.63, 2023: 0.63, 2024: 0.63, 2025: 0.63,
}

OUT_FIELDS = [
    'year','weight','cash_equiv_400','cash_or_savings_400','card_paid_full_400','card_pay_over_time_400','unable_pay_400_now','three_month_savings','doing_okay','financially_vulnerable','bill_pressure','income_cat','age_cat','educ_cat','race_cat','tenure','employment','has_child','region'
]


def ensure():
    for p in (RAW, PROCESSED, TABLES): p.mkdir(parents=True, exist_ok=True)

def download_year(year:int):
    out = RAW / f'SHED_public_use_data_{year}_CSV.zip'
    if out.exists() and out.stat().st_size > 100_000: return out, 'cached'
    errors=[]
    for tmpl in BASE_URLS:
        url=tmpl.format(year=year)
        req=urllib.request.Request(url, headers={'User-Agent':'Mozilla/5.0 (compatible; research-script/1.0)','Accept':'application/zip,*/*'})
        try:
            with urllib.request.urlopen(req, timeout=45) as r: data=r.read()
            if len(data) > 100_000:
                out.write_bytes(data); return out, url
            errors.append(f'{url}: small {len(data)}')
        except Exception as e: errors.append(f'{url}: {type(e).__name__} {e}')
    return None, '; '.join(errors[-2:])

def csv_entry(zpath:Path):
    with zipfile.ZipFile(zpath) as zf:
        infos=sorted([i for i in zf.infolist() if i.filename.lower().endswith('.csv')], key=lambda i:i.file_size, reverse=True)
        return infos[0].filename if infos else None

def parse_weight(v):
    try:
        if v is None or str(v).strip()=='': return None
        x=float(v); return x if x>0 and not math.isnan(x) else None
    except Exception: return None

def parse_yes(v):
    s=(v or '').strip().lower()
    if not s: return None
    no_tokens=['no','not selected','no, did not do this','no did not do this','0','0.0']
    yes_tokens=['yes','1','1.0']
    if s in no_tokens or s.startswith('no,') or s.startswith('no '): return 0
    if s in yes_tokens: return 1
    # Many earlier SHED multiple-response fields store the selected option text.
    return 1

def yn(v): return 'Yes' if v==1 else 'No' if v==0 else ''
def b2_doing_okay(v):
    s=(v or '').strip().lower()
    if s in {'living comfortably','doing okay'}: return 1
    if s in {'just getting by','finding it difficult to get by'}: return 0
    return None

def norm_income(v):
    s=(v or '').replace('–','-').strip()
    if not s: return ''
    if 'Less than $25,000' in s or 'Less than $10,000' in s or '$10,000 to $24,999' in s: return 'Less than $25,000'
    if '$25,000' in s and '$49,999' in s: return '$25,000-$49,999'
    if ('$50,000' in s and '$74,999' in s) or ('$75,000' in s and '$99,999' in s) or ('$50,000' in s and '$99,999' in s): return '$50,000-$99,999'
    if '$100,000' in s or '$150,000' in s or 'or more' in s: return '$100,000 or more'
    return s

def norm_educ(v):
    s=(v or '').strip()
    low=s.lower()
    if not s: return ''
    if 'less than' in low or 'no high school' in low: return 'Less than high school'
    if 'high school' in low and 'some college' not in low: return 'High school/GED'
    if 'some college' in low or 'associate' in low or 'technical' in low: return 'Some college/associate'
    if 'bachelor' in low or 'master' in low: return 'Bachelor or more'
    return s

def norm_tenure(v):
    s=(v or '').strip().lower()
    if not s: return ''
    if 'rent' in s and 'without payment' not in s: return 'Renter'
    if 'owned' in s or 'bought' in s: return 'Owner/buyer'
    if 'without payment' in s or 'neither' in s: return 'No cash rent/other'
    return (v or '').strip()

def norm_age(v):
    return (v or '').strip().replace('–','-')

def has_child(v):
    try: return yn(1 if int(float(v or '0'))>0 else 0)
    except Exception: return ''

def get(row, *names):
    for n in names:
        if n in row and row[n] not in (None,''): return row[n]
    return ''

def harmonize_row(year, row):
    w=parse_weight(get(row,'weight'))
    if w is None: return None
    ef3a=parse_yes(get(row,'EF3_a'))
    ef3b=parse_yes(get(row,'EF3_b'))
    ef3c=parse_yes(get(row,'EF3_c'))
    ef3h=parse_yes(get(row,'EF3_h'))
    pay=parse_yes(get(row,'pay_casheqv'))
    cash_equiv = pay if pay is not None else (1 if (ef3a==1 or ef3c==1) else 0 if (ef3a is not None or ef3c is not None) else None)
    b2=get(row,'B2')
    okay=parse_yes(get(row,'atleast_okay'))
    okay = okay if okay is not None else b2_doing_okay(b2)
    ef5c=parse_yes(get(row,'EF5C'))
    ef5d=parse_yes(get(row,'EF5D'))
    bill = 1 if (ef5c==0 or ef5d==1) else 0 if (ef5c==1 or ef5d==0) else None
    kids=has_child(get(row,'ppkid017'))
    return {
        'year':year,
        'weight':w,
        'cash_equiv_400':yn(cash_equiv),
        'cash_or_savings_400':yn(ef3c),
        'card_paid_full_400':yn(ef3a),
        'card_pay_over_time_400':yn(ef3b),
        'unable_pay_400_now':yn(ef3h),
        'three_month_savings':yn(parse_yes(get(row,'EF1'))),
        'doing_okay':yn(okay),
        'financially_vulnerable':yn(1-okay if okay is not None else None),
        'bill_pressure':yn(bill),
        'income_cat':norm_income(get(row,'inc_4cat_50k','ppinc7')),
        'age_cat':norm_age(get(row,'ppagect4','ppagecat')),
        'educ_cat':norm_educ(get(row,'educ_4cat','ppeducat')),
        'race_cat':(get(row,'race_5cat','ppethm') or '').strip(),
        'tenure':norm_tenure(get(row,'pprent')),
        'employment':(get(row,'ppemploy') or '').strip(),
        'has_child':kids,
        'region':(get(row,'ppreg4') or '').strip(),
    }

def read_year(year,z):
    out=[]
    entry=csv_entry(z)
    with zipfile.ZipFile(z) as zf, zf.open(entry) as f:
        reader=csv.DictReader((line.decode('utf-8-sig',errors='replace') for line in f))
        fields=reader.fieldnames or []
        for row in reader:
            hr=harmonize_row(year,row)
            if hr: out.append(hr)
    return out, entry, len(fields)

def parse_bool(v):
    s=(v or '').strip().lower()
    if s=='yes': return 1
    if s=='no': return 0
    return None

def wstat(rows,var,cond=None):
    n=0; num=den=sw2=0.0
    for r in rows:
        if cond and not cond(r): continue
        x=parse_bool(r.get(var)); w=parse_weight(r.get('weight'))
        if x is None or w is None: continue
        n+=1; num+=x*w; den+=w; sw2+=w*w
    p=num/den if den else None
    neff=den*den/sw2 if sw2 else None
    se=math.sqrt(max(p*(1-p),0)/neff) if p is not None and neff and neff>1 else None
    return {'n':n,'weighted_rate':p,'se':se,'ci_low':max(0,p-1.96*se) if se is not None else None,'ci_high':min(1,p+1.96*se) if se is not None else None}

def pct(v): return '' if v is None else f'{100*v:.1f}'

def write_csv(path, rows, headers):
    with path.open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=headers); w.writeheader(); w.writerows(rows)

def design_lpm(rows,outcome):
    controls=['income_cat','age_cat','educ_cat','race_cat','tenure','employment','has_child','region','year']
    use=[r for r in rows if parse_bool(r.get('cash_equiv_400')) is not None and parse_bool(r.get('three_month_savings')) is not None and parse_bool(r.get(outcome)) is not None]
    for r in use: r['_low_both']=yn(1 if parse_bool(r['cash_equiv_400'])==0 and parse_bool(r['three_month_savings'])==0 else 0)
    cats={c:sorted({str(r.get(c,'')) for r in use if str(r.get(c,''))}) for c in controls}
    names=['intercept','low_both']; X=[]; y=[]; w=[]
    for r in use:
        row=[1.0,float(parse_bool(r['_low_both']))]; ok=True
        for c,levels in cats.items():
            val=str(r.get(c,''))
            if not val: ok=False; break
            for lev in levels[1:]: row.append(1.0 if val==lev else 0.0)
        if ok:
            X.append(row); y.append(parse_bool(r[outcome])); w.append(float(r['weight']))
    if len(y)<100: return None
    X=np.array(X,float); y=np.array(y,float); w=np.array(w,float); sw=np.sqrt(w)
    Xw=X*sw[:,None]; yw=y*sw
    inv=np.linalg.pinv(Xw.T@Xw); beta=inv@(Xw.T@yw); resid=y-X@beta
    meat=(X.T*((w*resid)**2))@X; cov=inv@meat@inv; se=np.sqrt(np.maximum(np.diag(cov),0))
    k=1
    return {'outcome':outcome,'years':f"{min(int(r['year']) for r in use)}-{max(int(r['year']) for r in use)}",'n':len(y),'coef_low_both':beta[k],'se':se[k],'ci_low':beta[k]-1.96*se[k],'ci_high':beta[k]+1.96*se[k],'controls':'income, age, education, race/ethnicity, tenure, employment, children, region, year FE'}

def main():
    ensure(); allrows=[]; manifest=[]
    for year in YEARS:
        z,status=download_year(year)
        m={'year':year,'download_status':status,'zip_path':str(z.relative_to(ROOT)) if z else '', 'csv_entry':'','field_count':0,'rows':0}
        if z:
            try:
                rows,entry,fields=read_year(year,z); allrows.extend(rows); m.update({'csv_entry':entry,'field_count':fields,'rows':len(rows)})
            except Exception as e: m['download_status'] += f'; inspect_error={type(e).__name__}:{e}'
        manifest.append(m)
    write_csv(PROCESSED/'shed_2015_2025_harmonized_panel.csv', allrows, OUT_FIELDS)
    trend_vars=['cash_equiv_400','cash_or_savings_400','card_paid_full_400','card_pay_over_time_400','unable_pay_400_now','three_month_savings','doing_okay','financially_vulnerable','bill_pressure']
    trends=[]
    for year in sorted({int(r['year']) for r in allrows}):
        yr=[r for r in allrows if int(r['year'])==year]
        for var in trend_vars:
            st=wstat(yr,var)
            if st['n']:
                trends.append({'year':year,'variable':var,**st})
    write_csv(TABLES/'shed_2015_2025_harmonized_trends.csv',trends,['year','variable','n','weighted_rate','se','ci_low','ci_high'])
    # Low-buffer crosstabs 2020-2025 where constructed cash equivalence/doing okay strongest.
    cros=[]
    rows_2020=[r for r in allrows if int(r['year'])>=2020]
    for outcome in ['doing_okay','financially_vulnerable','unable_pay_400_now','bill_pressure']:
        for val in [0,1]:
            st=wstat(rows_2020,outcome,lambda r,val=val: parse_bool(r.get('cash_equiv_400'))==val)
            cros.append({'period':'2020-2025','group':f'cash_equiv_400={val}','outcome':outcome,**st})
    write_csv(TABLES/'shed_2020_2025_cash_equiv_crosstabs.csv',cros,['period','group','outcome','n','weighted_rate','se','ci_low','ci_high'])
    models=[m for m in [design_lpm([r for r in allrows if int(r['year'])>=2021],o) for o in ['financially_vulnerable','unable_pay_400_now','bill_pressure']] if m]
    write_csv(TABLES/'shed_2021_2025_adjusted_lpm.csv',models,['outcome','years','n','coef_low_both','se','ci_low','ci_high','controls'])
    # markdown summary
    lines=['# SHED Harmonized Multi-Year Tables','','## Table 1. Annual weighted rates with official benchmark','','Official cash/equiv $400 is the Federal Reserve published SHED report series. Constructed cash/equiv is derived from microdata component responses and is shown only as a diagnostic, not as the same object.','', '| Year | Official cash/equiv $400 | Constructed/direct diagnostic | Card over time | Unable $400 now | Three-month savings | Doing okay | Financially vulnerable |','|---:|---:|---:|---:|---:|---:|---:|---:|']
    by={(r['year'],r['variable']):r for r in trends}
    benchmark=[]
    for y in range(2015,2026):
        official=FED_OFFICIAL_CASH_EQUIV_400.get(y)
        diag=by.get((y,'cash_equiv_400'),{}).get('weighted_rate')
        diff=(diag-official) if diag is not None and official is not None else None
        benchmark.append({'year':y,'official_cash_equiv_400':official,'constructed_or_direct_cash_equiv_400':diag,'difference':diff})
        lines.append(f"| {y} | {pct(official)} | {pct(diag)} | {pct(by.get((y,'card_pay_over_time_400'),{}).get('weighted_rate'))} | {pct(by.get((y,'unable_pay_400_now'),{}).get('weighted_rate'))} | {pct(by.get((y,'three_month_savings'),{}).get('weighted_rate'))} | {pct(by.get((y,'doing_okay'),{}).get('weighted_rate'))} | {pct(by.get((y,'financially_vulnerable'),{}).get('weighted_rate'))} |")
    write_csv(TABLES/'shed_official_cash_equiv_benchmark.csv', benchmark, ['year','official_cash_equiv_400','constructed_or_direct_cash_equiv_400','difference'])
    lines += ['','## Table A1. Official benchmark vs constructed/direct diagnostic','','| Year | Official % | Constructed/direct diagnostic % | Difference (pp) |','|---:|---:|---:|---:|']
    for r in benchmark:
        diff='' if r['difference'] is None else f"{100*r['difference']:.1f}"
        lines.append(f"| {r['year']} | {pct(r['official_cash_equiv_400'])} | {pct(r['constructed_or_direct_cash_equiv_400'])} | {diff} |")
    lines += ['','## Table 2. 2020–2025 cash/equivalent cross-tabs','','| Group | Outcome | N | Weighted rate (%) | 95% CI (%) |','|---|---|---:|---:|---:|']
    for r in cros: lines.append(f"| `{r['group']}` | `{r['outcome']}` | {r['n']:,} | {pct(r['weighted_rate'])} | {pct(r['ci_low'])}–{pct(r['ci_high'])} |")
    lines += ['','## Table 3. 2021–2025 adjusted low-buffer associations','','Mechanical $400 inability outcomes are diagnostic only because they overlap with the $400 emergency-response item.','', '| Outcome | N | Low-buffer coefficient (pp) | SE (pp) | 95% CI (pp) |','|---|---:|---:|---:|---:|']
    for r in models: lines.append(f"| `{r['outcome']}` | {r['n']:,} | {100*r['coef_low_both']:.1f} | {100*r['se']:.1f} | {100*r['ci_low']:.1f}–{100*r['ci_high']:.1f} |")
    (TABLES/'shed_harmonized_multi_year_tables.md').write_text('\n'.join(lines)+'\n')
    (PROCESSED/'shed_2013_2025_harmonization_manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
    write_csv(TABLES/'shed_2013_2025_harmonization_manifest.csv',manifest,['year','download_status','zip_path','csv_entry','field_count','rows'])
    print(json.dumps({'rows':len(allrows),'years':sorted({int(r['year']) for r in allrows}),'outputs':['data/processed/shed_2015_2025_harmonized_panel.csv','tables/shed_2015_2025_harmonized_trends.csv','tables/shed_2020_2025_cash_equiv_crosstabs.csv','tables/shed_2021_2025_adjusted_lpm.csv','tables/shed_harmonized_multi_year_tables.md','tables/shed_official_cash_equiv_benchmark.csv']},indent=2))
if __name__=='__main__': main()
