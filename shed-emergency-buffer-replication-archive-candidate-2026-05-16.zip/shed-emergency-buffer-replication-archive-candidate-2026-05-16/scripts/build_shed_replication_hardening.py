#!/usr/bin/env python3
"""Build replication-hardening tables for the SHED emergency-buffer work.

The goal is not to create another substantive result paper. It is to make the
SHED repeated-cross-section measurement note more defensible by documenting:
source provenance, variable/year mapping, official-topline benchmarking,
bridge diagnostics, heterogeneity checks, variance limitations, and software
capture.
"""
from __future__ import annotations

import csv
import json
import math
import platform
import sys
import zipfile
from collections import defaultdict
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
RAW = ROOT / "data" / "raw"
PROCESSED = ROOT / "data" / "processed"
TABLES = ROOT / "tables"
DOCS = ROOT / "docs" / "replication"

YEARS = range(2013, 2026)
OFFICIAL_CASH_EQUIV = {
    2015: 0.54, 2016: 0.56, 2017: 0.59, 2018: 0.61, 2019: 0.63,
    2020: 0.64, 2021: 0.68, 2022: 0.63, 2023: 0.63, 2024: 0.63, 2025: 0.63,
}

VARIABLE_SPECS = [
    {
        "construct": "cash_equiv_400",
        "raw_variables": "pay_casheqv; EF3_a; EF3_c",
        "usable_window": "Official benchmark 2015-2025; direct microdata pay_casheqv 2020-2025; component diagnostic only before 2020",
        "question_or_role": "Whether respondent would cover a $400 emergency expense completely using cash or its equivalent; component diagnostic uses credit-card-paid-in-full and checking/savings/cash response options.",
        "denominator": "Adults with valid emergency-expense response and positive final weight; official topline uses Federal Reserve published SHED report series.",
        "coding": "Yes=1, No=0. Before 2020, component-built values are not treated as equivalent to the official/direct measure.",
        "caveat": "Central measurement caveat: pre-2020 component rule overstates the official series by 8-13 pp and is diagnostic only.",
    },
    {
        "construct": "three_month_savings",
        "raw_variables": "EF1",
        "usable_window": "2015-2025 trend; richer covariate analysis mainly 2021-2025",
        "question_or_role": "Whether respondent has set aside emergency/rainy-day funds that would cover expenses for three months.",
        "denominator": "Adults with valid EF1 response and positive final weight.",
        "coding": "Yes=1, No=0.",
        "caveat": "Repeated cross-section; not within-person savings accumulation.",
    },
    {
        "construct": "financially_vulnerable / doing_okay",
        "raw_variables": "B2; atleast_okay",
        "usable_window": "B2-derived coding available broadly; atleast_okay direct variable from 2020 onward in inspected files",
        "question_or_role": "Current financial well-being: living comfortably / doing okay versus just getting by / finding it difficult.",
        "denominator": "Adults with valid financial-well-being response and positive final weight.",
        "coding": "Doing okay=1 for living comfortably or doing okay; financially vulnerable=1 for just getting by or finding it difficult.",
        "caveat": "Subjective financial status; not a balance-sheet measure.",
    },
    {
        "construct": "bill_pressure",
        "raw_variables": "EF5C; EF5D",
        "usable_window": "Use cautiously; main adjusted analysis limited to 2021-2025, not a 2015-2025 headline trend",
        "question_or_role": "Recent bill-payment pressure / inability or difficulty paying bills in inspected SHED files.",
        "denominator": "Adults with valid bill-pressure response and positive final weight.",
        "coding": "Coded to indicate bill pressure where comparable in the analysis window.",
        "caveat": "Definitions are not comparable enough for a full-period trend claim.",
    },
    {
        "construct": "card_pay_over_time_400",
        "raw_variables": "EF3_b",
        "usable_window": "2015-2025 descriptive series",
        "question_or_role": "Would put $400 emergency expense on a credit card and pay it off over time.",
        "denominator": "Adults with valid emergency-expense response and positive final weight.",
        "coding": "Selected option=1, no/not selected=0.",
        "caveat": "Not cash-equivalent; explicitly distinct from pay_casheqv.",
    },
    {
        "construct": "covariates",
        "raw_variables": "inc_4cat_50k; ppinc7; ppagect4; ppagecat; educ_4cat; ppeducat; race_5cat; ppethm; pprent; ppemploy; ppkid017; ppreg4",
        "usable_window": "Richest consistent adjusted-analysis coverage 2021-2025",
        "question_or_role": "Demographic/economic controls and heterogeneity groups.",
        "denominator": "Adults with non-missing construct, outcome, covariates, and positive final weight.",
        "coding": "Collapsed categories used for descriptive heterogeneity and approximate adjusted models.",
        "caveat": "Public-use categories are coarse; adjusted models are descriptive, not causal.",
    },
]


def ensure() -> None:
    for p in (TABLES, DOCS):
        p.mkdir(parents=True, exist_ok=True)


def csv_entry(zpath: Path) -> str | None:
    with zipfile.ZipFile(zpath) as zf:
        infos = sorted(
            [i for i in zf.infolist() if i.filename.lower().endswith(".csv")],
            key=lambda i: i.file_size,
            reverse=True,
        )
        return infos[0].filename if infos else None


def write_csv(path: Path, rows: list[dict], headers: list[str] | None = None) -> None:
    if headers is None:
        headers = list(rows[0].keys()) if rows else []
    with path.open("w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=headers)
        w.writeheader()
        w.writerows(rows)


def md_table(headers: list[str], rows: list[list[str]]) -> str:
    out = ["| " + " | ".join(headers) + " |", "|" + "|".join(["---"] * len(headers)) + "|"]
    out += ["| " + " | ".join(str(c) for c in row) + " |" for row in rows]
    return "\n".join(out)


def pct(v) -> str:
    if v in (None, ""):
        return ""
    return f"{100 * float(v):.1f}"


def parse_weight(v):
    try:
        if v is None or str(v).strip() == "":
            return None
        x = float(v)
        return x if x > 0 and not math.isnan(x) else None
    except Exception:
        return None


def parse_bool(v):
    s = (v or "").strip().lower()
    if s == "yes":
        return 1
    if s == "no":
        return 0
    return None


def wstat(rows: list[dict], var: str, cond=None) -> dict:
    n = 0
    num = den = sw2 = 0.0
    for r in rows:
        if cond and not cond(r):
            continue
        x = parse_bool(r.get(var))
        w = parse_weight(r.get("weight"))
        if x is None or w is None:
            continue
        n += 1
        num += x * w
        den += w
        sw2 += w * w
    p = num / den if den else None
    neff = den * den / sw2 if sw2 else None
    se = math.sqrt(max(p * (1 - p), 0) / neff) if p is not None and neff and neff > 1 else None
    return {
        "n": n,
        "weighted_rate": p,
        "se": se,
        "ci_low": max(0, p - 1.96 * se) if se is not None else None,
        "ci_high": min(1, p + 1.96 * se) if se is not None else None,
    }


def build_raw_variable_presence() -> list[dict]:
    wanted = sorted({v.strip() for spec in VARIABLE_SPECS for v in spec["raw_variables"].split(";")})
    rows = []
    field_manifest = {}
    for year in YEARS:
        z = RAW / f"SHED_public_use_data_{year}_CSV.zip"
        fields = set()
        if z.exists():
            try:
                with zipfile.ZipFile(z) as zf, zf.open(csv_entry(z)) as f:
                    reader = csv.DictReader((line.decode("utf-8-sig", errors="replace") for line in f))
                    fields = set(reader.fieldnames or [])
            except Exception:
                fields = set()
        field_manifest[year] = fields
    for var in wanted:
        present = [str(y) for y, fields in field_manifest.items() if var in fields]
        rows.append({
            "raw_variable": var,
            "years_present": ", ".join(present),
            "first_year": present[0] if present else "",
            "last_year": present[-1] if present else "",
            "n_years": len(present),
        })
    return rows


def build_variable_map() -> None:
    presence = build_raw_variable_presence()
    write_csv(TABLES / "shed_replication_raw_variable_presence.csv", presence)

    spec_rows = []
    by_var = {r["raw_variable"]: r for r in presence}
    for spec in VARIABLE_SPECS:
        raw_vars = [v.strip() for v in spec["raw_variables"].split(";")]
        spec_rows.append({
            **spec,
            "raw_presence_summary": "; ".join(f"{v}: {by_var.get(v, {}).get('years_present', '')}" for v in raw_vars),
        })
    headers = ["construct", "raw_variables", "usable_window", "question_or_role", "denominator", "coding", "caveat", "raw_presence_summary"]
    write_csv(TABLES / "shed_replication_variable_map.csv", spec_rows, headers)

    md = [
        "# SHED Replication Variable Map",
        "",
        "This table is a replication-grade map of the constructs used in the emergency-buffer notes. It separates official published top-line measures from author-constructed diagnostics and records the current harmonization boundary.",
        "",
        md_table(
            ["Construct", "Raw variables", "Usable window", "Denominator/coding", "Key caveat"],
            [[r["construct"], f"`{r['raw_variables']}`", r["usable_window"], r["denominator"] + " " + r["coding"], r["caveat"]] for r in spec_rows],
        ),
        "",
        "## Raw variable presence",
        "",
        md_table(
            ["Raw variable", "Years present", "N years"],
            [[r["raw_variable"], r["years_present"], str(r["n_years"])] for r in presence],
        ),
    ]
    (DOCS / "shed_replication_variable_map.md").write_text("\n".join(md) + "\n")


def build_official_reproduction() -> None:
    benchmark_path = TABLES / "shed_official_cash_equiv_benchmark.csv"
    rows = []
    if benchmark_path.exists():
        with benchmark_path.open() as f:
            for r in csv.DictReader(f):
                year = int(r["year"])
                official = float(r["official_cash_equiv_400"])
                diag = float(r["constructed_or_direct_cash_equiv_400"]) if r["constructed_or_direct_cash_equiv_400"] else None
                rows.append({
                    "year": year,
                    "official_cash_equiv_400_pct": f"{100*official:.1f}",
                    "microdata_diagnostic_pct": f"{100*diag:.1f}" if diag is not None else "",
                    "diagnostic_minus_official_pp": f"{100*(diag-official):.1f}" if diag is not None else "",
                    "status": "direct/near-direct validation window" if year >= 2020 else "component diagnostic not equivalent",
                })
    write_csv(TABLES / "shed_official_topline_reproduction.csv", rows)
    md = [
        "# SHED Official Topline Reproduction / Benchmark",
        "",
        "This table treats the Federal Reserve published SHED $400 cash/equivalent series as the benchmark. The microdata component diagnostic is shown to document why pre-2020 values cannot be used as the same measure.",
        "",
        md_table(
            ["Year", "Official %", "Microdata diagnostic %", "Diff pp", "Status"],
            [[r["year"], r["official_cash_equiv_400_pct"], r["microdata_diagnostic_pct"], r["diagnostic_minus_official_pp"], r["status"]] for r in rows],
        ),
    ]
    (DOCS / "shed_official_topline_reproduction.md").write_text("\n".join(md) + "\n")


def build_heterogeneity() -> None:
    panel = PROCESSED / "shed_2015_2025_harmonized_panel.csv"
    with panel.open() as f:
        all_rows = list(csv.DictReader(f))
    rows = [r for r in all_rows if int(r["year"]) >= 2021]
    for r in rows:
        c = parse_bool(r.get("cash_equiv_400"))
        s = parse_bool(r.get("three_month_savings"))
        r["low_both_buffers"] = "Yes" if c == 0 and s == 0 else "No" if c is not None and s is not None else ""

    groups = [
        ("income_cat", "Income"),
        ("tenure", "Housing tenure"),
        ("age_cat", "Age"),
        ("has_child", "Children in household"),
        ("employment", "Employment"),
        ("race_cat", "Race/ethnicity"),
    ]
    out = []
    allowed_levels = {
        "income_cat": {"Less than $25,000", "$25,000-$49,999", "$50,000-$99,999", "$100,000 or more"},
        "tenure": {"Owner/buyer", "Renter", "No cash rent/other"},
        "age_cat": {"18-29", "30-44", "45-59", "60+"},
        "has_child": {"Yes", "No"},
        # Employment and race/ethnicity labels vary less cleanly; keep levels only when sample is substantial.
        "employment": None,
        "race_cat": None,
    }
    for field, label in groups:
        levels = sorted({r.get(field, "") for r in rows if r.get(field, "")})
        if allowed_levels[field] is not None:
            levels = [x for x in levels if x in allowed_levels[field]]
        for level in levels:
            cond = lambda r, field=field, level=level: r.get(field) == level
            low = wstat(rows, "low_both_buffers", cond)
            if low["n"] < 100:
                continue
            vuln = wstat(rows, "financially_vulnerable", cond)
            bill = wstat(rows, "bill_pressure", cond)
            out.append({
                "group_type": label,
                "group": level,
                "n_low_buffer_denom": low["n"],
                "low_both_buffers_pct": pct(low["weighted_rate"]),
                "financially_vulnerable_pct": pct(vuln["weighted_rate"]),
                "bill_pressure_pct": pct(bill["weighted_rate"]),
                "bill_pressure_n": bill["n"],
            })
    headers = ["group_type", "group", "n_low_buffer_denom", "low_both_buffers_pct", "financially_vulnerable_pct", "bill_pressure_pct", "bill_pressure_n"]
    write_csv(TABLES / "shed_2021_2025_replication_heterogeneity.csv", out, headers)

    # Keep manuscript table concise: income, tenure, age, children only.
    manuscript = [r for r in out if r["group_type"] in {"Income", "Housing tenure", "Age", "Children in household"}]
    md = [
        "# SHED 2021–2025 Heterogeneity Checks",
        "",
        "Weighted descriptive subgroup checks for the replication package. Low buffer means lacking both $400 cash/equivalent capacity and three-month emergency savings. These are repeated-cross-section associations, not causal estimates.",
        "",
        md_table(
            ["Group type", "Group", "N", "Low both buffers %", "Financially vulnerable %", "Bill pressure %"],
            [[r["group_type"], r["group"], f"{int(r['n_low_buffer_denom']):,}" if r["n_low_buffer_denom"] else "", r["low_both_buffers_pct"], r["financially_vulnerable_pct"], r["bill_pressure_pct"]] for r in manuscript],
        ),
    ]
    (DOCS / "shed_2021_2025_heterogeneity.md").write_text("\n".join(md) + "\n")


def build_variance_and_dependencies() -> None:
    variance = """# SHED Variance Strategy and Limits

The current replication package reports approximate weighted confidence intervals using final weights and a Kish-style effective sample size. This is useful for scale and transparency, but it is not a full survey-design variance estimator.

## Current strategy

- Use final respondent weights where available.
- Compute weighted proportions.
- Approximate effective sample size as `(sum w)^2 / sum(w^2)`.
- Use normal-approximation intervals for descriptive proportions.
- Use heteroskedasticity-robust weighted linear probability models for adjusted descriptive associations.

## Limits

- The current scripts do not use replicate weights, strata, or primary sampling units.
- Confidence intervals should be treated as approximate.
- Adjusted models are descriptive controls, not causal designs.
- Public-use variable harmonization, skip patterns, and question wording remain at least as important as sampling variance for the main measurement claims.

## Publication-grade upgrade

A publication-grade release should either implement the Federal Reserve's recommended survey-design variance approach for the relevant SHED files or explicitly justify why final-weight/Kish approximations are adequate for a public measurement note.
"""
    (DOCS / "shed_variance_strategy.md").write_text(variance)

    deps = {
        "python_version": sys.version,
        "platform": platform.platform(),
        "executable": sys.executable,
        "scripts": [
            "build_shed_replication_provenance.py",
            "build_shed_overlap_bridge.py",
            "build_shed_harmonized_panel.py",
            "build_shed_replication_hardening.py",
            "export_shed_replication_methodology.py",
        ],
        "external_runtime_note": "PDF export uses local Node Playwright/Chromium when available; statistical tables are built with Python standard library plus numpy in the harmonized-panel script.",
    }
    (DOCS / "software_environment.json").write_text(json.dumps(deps, indent=2) + "\n")
    md = ["# Software Environment", "", f"- Python: `{platform.python_version()}`", f"- Platform: `{platform.platform()}`", f"- Python executable: `{sys.executable}`", "", "The table-building scripts are designed to be local-first. Existing adjusted-model scripts use `numpy`; the replication-hardening script itself uses the Python standard library."]
    (DOCS / "software_environment.md").write_text("\n".join(md) + "\n")


def update_readme() -> None:
    readme = DOCS / "README.md"
    text = readme.read_text() if readme.exists() else "# SHED Emergency-Buffer Replication Package\n"
    add = """

## Finished-draft replication hardening additions — 2026-05-15

Additional replication-grade artifacts now included:

- `shed_replication_variable_map.md` / `shed_replication_variable_map.csv` — construct-to-variable map, denominators, coding, caveats, and raw-variable year presence.
- `shed_official_topline_reproduction.md` / `shed_official_topline_reproduction.csv` — official Federal Reserve benchmark series versus the microdata diagnostic.
- `shed_2021_2025_heterogeneity.md` / `shed_2021_2025_replication_heterogeneity.csv` — subgroup checks by income, tenure, age, children, employment, and race/ethnicity.
- `shed_variance_strategy.md` — current approximate weighted-interval strategy and publication-grade limits.
- `software_environment.md` / `.json` — local runtime and dependency capture.
- `SHED_Emergency_Buffer_Replication_Methodology_Draft.pdf` — finished methodology/replication draft.

Current status: finished-draft replication package, not final publication-grade archive. Remaining upgrades are exact codebook text extraction for every wave, survey-design variance if available, and a fully frozen public release bundle.
"""
    if "Finished-draft replication hardening additions" not in text:
        text += add
    readme.write_text(text.rstrip() + "\n")


def main() -> None:
    ensure()
    build_variable_map()
    build_official_reproduction()
    build_heterogeneity()
    build_variance_and_dependencies()
    update_readme()
    print(json.dumps({
        "outputs": [
            "tables/shed_replication_variable_map.csv",
            "tables/shed_replication_raw_variable_presence.csv",
            "tables/shed_official_topline_reproduction.csv",
            "tables/shed_2021_2025_replication_heterogeneity.csv",
            "docs/replication/shed_replication_variable_map.md",
            "docs/replication/shed_official_topline_reproduction.md",
            "docs/replication/shed_2021_2025_heterogeneity.md",
            "docs/replication/shed_variance_strategy.md",
            "docs/replication/software_environment.md",
        ]
    }, indent=2))


if __name__ == "__main__":
    main()
