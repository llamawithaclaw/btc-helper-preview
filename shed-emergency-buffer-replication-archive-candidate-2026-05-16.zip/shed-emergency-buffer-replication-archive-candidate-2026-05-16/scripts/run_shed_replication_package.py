#!/usr/bin/env python3
"""One-command rebuild wrapper for the SHED emergency-buffer replication package."""
from __future__ import annotations
import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SCRIPTS = ROOT / "scripts"
COMMANDS = [
    [sys.executable, str(SCRIPTS / "build_shed_replication_provenance.py")],
    [sys.executable, str(SCRIPTS / "build_shed_overlap_bridge.py")],
    [sys.executable, str(SCRIPTS / "build_shed_harmonized_panel.py")],
    [sys.executable, str(SCRIPTS / "build_shed_replication_hardening.py")],
    [sys.executable, str(SCRIPTS / "export_shed_replication_methodology.py")],
]


def main() -> None:
    results = []
    for cmd in COMMANDS:
        proc = subprocess.run(cmd, cwd=ROOT, text=True, capture_output=True)
        results.append({
            "command": " ".join(cmd),
            "returncode": proc.returncode,
            "stdout_tail": proc.stdout[-1200:],
            "stderr_tail": proc.stderr[-1200:],
        })
        if proc.returncode != 0:
            print(json.dumps({"failed": results[-1], "completed": results[:-1]}, indent=2))
            raise SystemExit(proc.returncode)
    print(json.dumps({"status": "ok", "commands": results}, indent=2))


if __name__ == "__main__":
    main()
