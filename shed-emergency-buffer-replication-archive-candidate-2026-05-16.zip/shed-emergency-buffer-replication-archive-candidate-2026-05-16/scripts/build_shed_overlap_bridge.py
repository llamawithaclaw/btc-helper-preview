#!/usr/bin/env python3
"""Bridge diagnostic: compare component-built $400 cash/equivalent to pay_casheqv.

For overlap years where pay_casheqv is present, compare the direct Federal
Reserve constructed variable to a simple component rule:
  EF3_a (credit card paid in full) OR EF3_c (checking/savings/cash).

This tests the exact failure mode flagged by the referee: whether the component
construction is equivalent to the official/direct measure.
"""
from __future__ import annotations
import csv, json, math, zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
RAW = ROOT / 'data' / 'raw'
TABLES = ROOT / 'tables'
DOCS = ROOT / 'docs' / 'replication'
YEARS = range(2020, 2026)


def parse_weight(v):
    try:
        if v is None or str(v).strip() == '': return None
        x = float(v)
        return x if x > 0 and not math.isnan(x) else None
    except Exception:
        return None


def parse_yes(v):
    s = (v or '').strip().lower()
    if not s: return None
    if s in {'no','not selected','no, did not do this','no did not do this','0','0.0'} or s.startswith('no,') or s.startswith('no '): return 0
    if s in {'yes','1','1.0'}: return 1
    return 1


def csv_entry(zpath:Path):
    with zipfile.ZipFile(zpath) as zf:
        infos = sorted([i for i in zf.infolist() if i.filename.lower().endswith('.csv')], key=lambda i: i.file_size, reverse=True)
        return infos[0].filename if infos else None


def weighted_rate(num, den):
    return num / den if den else None


def fmt(v):
    return '' if v is None else f'{100*v:.1f}'


def main():
    TABLES.mkdir(parents=True, exist_ok=True)
    DOCS.mkdir(parents=True, exist_ok=True)
    rows=[]
    pooled={'n':0,'den':0.0,'agree':0.0,'fp':0.0,'fn':0.0,'direct':0.0,'component':0.0}
    for year in YEARS:
        z = RAW / f'SHED_public_use_data_{year}_CSV.zip'
        if not z.exists():
            continue
        m={'n':0,'den':0.0,'agree':0.0,'fp':0.0,'fn':0.0,'direct':0.0,'component':0.0}
        with zipfile.ZipFile(z) as zf, zf.open(csv_entry(z)) as f:
            reader = csv.DictReader((line.decode('utf-8-sig', errors='replace') for line in f))
            for r in reader:
                w = parse_weight(r.get('weight'))
                direct = parse_yes(r.get('pay_casheqv'))
                ef3a = parse_yes(r.get('EF3_a'))
                ef3c = parse_yes(r.get('EF3_c'))
                if w is None or direct is None or (ef3a is None and ef3c is None):
                    continue
                component = 1 if (ef3a == 1 or ef3c == 1) else 0
                m['n'] += 1; m['den'] += w; pooled['n'] += 1; pooled['den'] += w
                for obj in (m, pooled):
                    obj['direct'] += direct * w
                    obj['component'] += component * w
                    obj['agree'] += (1 if direct == component else 0) * w
                    obj['fp'] += (1 if component == 1 and direct == 0 else 0) * w
                    obj['fn'] += (1 if component == 0 and direct == 1 else 0) * w
        rows.append({
            'year':year,
            'n':m['n'],
            'direct_pay_casheqv_rate':weighted_rate(m['direct'],m['den']),
            'component_rule_rate':weighted_rate(m['component'],m['den']),
            'component_minus_direct':weighted_rate(m['component'],m['den'])-weighted_rate(m['direct'],m['den']) if m['den'] else None,
            'weighted_agreement_rate':weighted_rate(m['agree'],m['den']),
            'weighted_false_positive_rate':weighted_rate(m['fp'],m['den']),
            'weighted_false_negative_rate':weighted_rate(m['fn'],m['den']),
        })
    rows.append({
        'year':'2020-2025 pooled',
        'n':pooled['n'],
        'direct_pay_casheqv_rate':weighted_rate(pooled['direct'],pooled['den']),
        'component_rule_rate':weighted_rate(pooled['component'],pooled['den']),
        'component_minus_direct':weighted_rate(pooled['component'],pooled['den'])-weighted_rate(pooled['direct'],pooled['den']) if pooled['den'] else None,
        'weighted_agreement_rate':weighted_rate(pooled['agree'],pooled['den']),
        'weighted_false_positive_rate':weighted_rate(pooled['fp'],pooled['den']),
        'weighted_false_negative_rate':weighted_rate(pooled['fn'],pooled['den']),
    })
    headers=list(rows[0].keys())
    out=TABLES/'shed_2020_2025_pay_casheqv_component_bridge.csv'
    with out.open('w', newline='') as f:
        w=csv.DictWriter(f, fieldnames=headers); w.writeheader(); w.writerows(rows)
    md=['# SHED pay_casheqv Component Bridge', '', 'Direct measure: `pay_casheqv`. Component rule: `EF3_a` credit-card-paid-in-full OR `EF3_c` checking/savings/cash. False positive means component rule = 1 while direct `pay_casheqv` = 0.', '', '| Year | N | Direct % | Component % | Diff pp | Agreement % | False positive % | False negative % |', '|---|---:|---:|---:|---:|---:|---:|---:|']
    for r in rows:
        md.append(f"| {r['year']} | {r['n']:,} | {fmt(r['direct_pay_casheqv_rate'])} | {fmt(r['component_rule_rate'])} | {fmt(r['component_minus_direct'])} | {fmt(r['weighted_agreement_rate'])} | {fmt(r['weighted_false_positive_rate'])} | {fmt(r['weighted_false_negative_rate'])} |")
    (DOCS/'shed_pay_casheqv_component_bridge.md').write_text('\n'.join(md)+'\n')
    (DOCS/'shed_pay_casheqv_component_bridge.json').write_text(json.dumps(rows, indent=2))
    print(json.dumps({'rows':len(rows),'csv':str(out),'md':str(DOCS/'shed_pay_casheqv_component_bridge.md')}, indent=2))

if __name__ == '__main__':
    main()
