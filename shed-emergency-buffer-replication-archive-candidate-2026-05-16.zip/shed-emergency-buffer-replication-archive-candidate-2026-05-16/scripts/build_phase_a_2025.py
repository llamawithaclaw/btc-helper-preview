#!/usr/bin/env python3
"""Build revised Phase A SHED 2025 tables for Paper XI.

Portable standard-library + NumPy build. Outputs weighted descriptive rates,
approximate CIs, denominator/skip-pattern audit tables, selected cross-tabs,
subgroup tables, and approximate weighted linear-probability models.
"""

from __future__ import annotations

import csv
import json
import math
import urllib.request
import zipfile
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
RAW = ROOT / "data" / "raw"
PROCESSED = ROOT / "data" / "processed"
TABLES = ROOT / "tables"

ZIP_URL = "https://www.federalreserve.gov/consumerscommunities/files/SHED_public_use_data_2025_(CSV).zip"
ZIP_PATH = RAW / "SHED_public_use_data_2025_CSV.zip"
CSV_NAME = "public2025.csv"

BASE_FIELDS = [
    "weight", "weight_pop", "B2", "pay_casheqv", "EF1", "EF2", "EF3_a", "EF3_b", "EF3_c",
    "EF3_d", "EF3_e", "EF3_f", "EF3_g", "EF3_h", "EF5C", "EF5D", "EF8_a", "EF8_b", "EF8_c",
    "EF8_d", "EF8_e", "EF8_f", "EF8_g", "EF8_h", "EF8_i", "EF8_j", "atleast_okay", "FS21_a",
    "FS21_b", "FS21_c", "FS21_d", "FS21_e", "FS21_f", "FS21_g", "A0", "A0B", "A1_a", "A1_b",
    "BNPL1", "BNPL3", "BNPL3A", "E2", "E2B", "X12_f", "ppagecat", "ppagect4", "ppeducat",
    "educ_4cat", "ppethm", "race_5cat", "ppgender", "ppemploy", "ppinc7", "inc_4cat_50k", "pprent",
    "ppkid017", "ppmsacat", "ppreg4",
]

DERIVED_FIELDS = [
    "not_atleast_okay", "financially_vulnerable_b2", "fs21_any_external_help", "credit_constrained",
    "bnpl_late_or_fee", "low_buffer_both", "low_savings_pay_overtime", "unable_pay_400_now",
    "borrow_family_or_high_cost_400", "borrow_any_400", "bill_pressure", "paid_all_bills_full",
    "difficulty_paying_bills", "unexpected_medical_expense", "medical_debt", "major_medical_concern",
    "has_child_under_18",
]
FIELDS = BASE_FIELDS + DERIVED_FIELDS

VARIABLE_DOC = {
    "pay_casheqv": ["Would cover a $400 emergency with cash or equivalent", "All respondents, constructed by Federal Reserve", "constructed binary"],
    "EF1": ["Set aside emergency/rainy-day funds covering three months of expenses", "All respondents", "single-response binary"],
    "EF2": ["Could cover three months by borrowing, savings, or selling assets if income lost", "Follow-up among those without three-month rainy-day funds", "conditional binary"],
    "EF3_a": ["Put $400 emergency on credit card and pay in full", "All respondents; multiple response", "binary response option"],
    "EF3_b": ["Put $400 emergency on credit card and pay over time", "All respondents; multiple response", "binary response option"],
    "EF3_c": ["Pay $400 emergency with checking/savings/cash", "All respondents; multiple response", "binary response option"],
    "EF3_h": ["Would not be able to pay $400 emergency right now", "All respondents; multiple response", "binary response option"],
    "atleast_okay": ["Doing okay financially", "All respondents, constructed by Federal Reserve", "constructed binary"],
    "B2": ["Overall financial management status", "All respondents", "single-response categorical"],
    "EF5C": ["Paid all non-credit-card bills in full last month", "All respondents", "single-response binary"],
    "EF5D": ["Had bills difficult to pay last month", "Asked where applicable after bill-payment screen", "conditional binary"],
    "FS21_a-FS21_g": ["Outside-household help with listed expenses", "All respondents; multiple response", "author OR construction"],
    "A0B/A1_a/A1_b": ["Desired credit but did not apply, denied, or received less than requested", "Credit-access items with skip patterns", "author OR construction"],
    "BNPL3/BNPL3A": ["BNPL late payment or extra fee", "BNPL users with follow-up", "conditional author OR construction"],
    "E2": ["Unexpected major medical expenses paid out of pocket", "All respondents", "single-response binary"],
    "E2B": ["Currently has debt from medical care", "All respondents", "single-response binary"],
    "X12_f": ["Medical debt or affording medical care as financial concern", "Split-sample/rotating concern item where observed", "categorical concern item"],
}


def ensure_dirs():
    for path in (RAW, PROCESSED, TABLES): path.mkdir(parents=True, exist_ok=True)


def download_if_needed():
    if ZIP_PATH.exists() and ZIP_PATH.stat().st_size > 1_000_000: return
    req = urllib.request.Request(ZIP_URL, headers={"User-Agent":"Mozilla/5.0 (compatible; research-script/1.0; +https://btchelper.app)", "Accept":"application/zip,*/*"})
    with urllib.request.urlopen(req, timeout=60) as response: ZIP_PATH.write_bytes(response.read())


def parse_bool(value):
    v = (value or "").strip().lower()
    if v in {"0", "0.0", "no", "false", "not selected"}: return 0
    if v in {"1", "1.0", "yes", "true"}: return 1
    return None


def parse_float(value):
    try:
        if value is None or str(value).strip() == "": return None
        out = float(value)
        return None if math.isnan(out) else out
    except Exception: return None


def yn(v): return "Yes" if v == 1 else "No" if v == 0 else ""
def bool_or(*values):
    parsed = [parse_bool(v) for v in values]
    if any(v == 1 for v in parsed): return "Yes"
    if any(v == 0 for v in parsed): return "No"
    return ""
def bool_and(*values):
    parsed = [parse_bool(v) for v in values]
    if any(v is None for v in parsed): return ""
    return "Yes" if all(v == 1 for v in parsed) else "No"
def bool_not(value):
    p = parse_bool(value)
    return "" if p is None else yn(1 - p)


def derive(row):
    out = dict(row)
    b2 = (row.get("B2") or "").strip().lower()
    out["not_atleast_okay"] = bool_not(row.get("atleast_okay"))
    out["financially_vulnerable_b2"] = "Yes" if b2 in {"just getting by", "finding it difficult to get by"} else ("No" if b2 else "")
    out["fs21_any_external_help"] = bool_or(*(row.get(f"FS21_{s}") for s in "abcdefg"))
    out["credit_constrained"] = bool_or(row.get("A0B"), row.get("A1_a"), row.get("A1_b"))
    out["bnpl_late_or_fee"] = bool_or(row.get("BNPL3"), row.get("BNPL3A")) if parse_bool(row.get("BNPL1")) == 1 else ""
    pay_no = yn(1) if parse_bool(row.get("pay_casheqv")) == 0 else (yn(0) if parse_bool(row.get("pay_casheqv")) == 1 else "")
    ef1_no = yn(1) if parse_bool(row.get("EF1")) == 0 else (yn(0) if parse_bool(row.get("EF1")) == 1 else "")
    out["low_buffer_both"] = bool_and(pay_no, ef1_no)
    out["low_savings_pay_overtime"] = bool_and(ef1_no, row.get("EF3_b"))
    out["unable_pay_400_now"] = row.get("EF3_h", "")
    out["borrow_family_or_high_cost_400"] = bool_or(row.get("EF3_e"), row.get("EF3_f"))
    out["borrow_any_400"] = bool_or(row.get("EF3_b"), row.get("EF3_d"), row.get("EF3_e"), row.get("EF3_f"))
    out["paid_all_bills_full"] = row.get("EF5C", "")
    out["difficulty_paying_bills"] = row.get("EF5D", "")
    # Conservative concrete bill-pressure proxy: did not pay all bills in full OR reported difficult bills.
    out["bill_pressure"] = bool_or(bool_not(row.get("EF5C")), row.get("EF5D"))
    out["unexpected_medical_expense"] = row.get("E2", "")
    out["medical_debt"] = row.get("E2B", "")
    out["major_medical_concern"] = "Yes" if (row.get("X12_f") or "").strip().lower() == "major concern" else ("No" if row.get("X12_f") else "")
    try: kids = int(float(row.get("ppkid017") or "")); out["has_child_under_18"] = yn(1 if kids > 0 else 0)
    except Exception: out["has_child_under_18"] = ""
    return out


def selected_rows():
    with zipfile.ZipFile(ZIP_PATH) as zf, zf.open(CSV_NAME) as f:
        reader = csv.DictReader((line.decode("utf-8-sig", errors="replace") for line in f))
        missing = [field for field in BASE_FIELDS if field not in (reader.fieldnames or [])]
        if missing: raise RuntimeError(f"Missing expected fields: {missing}")
        for row in reader: yield derive({field: row.get(field, "") for field in BASE_FIELDS})


def weighted_stat(rows, var, condition=None):
    numer=denom=sumw2=0.0; n=0
    for row in rows:
        if condition and not condition(row): continue
        x=parse_bool(row.get(var,"")); w=parse_float(row.get("weight",""))
        if x is None or w is None or w<=0: continue
        numer += x*w; denom += w; sumw2 += w*w; n += 1
    p = numer/denom if denom else None
    neff = denom*denom/sumw2 if sumw2 else None
    se = math.sqrt(max(p*(1-p),0)/neff) if p is not None and neff and neff>1 else None
    return {"n_unweighted":n,"weighted_denominator":denom,"weighted_rate":p,"neff":neff,"se":se,"ci_low":max(0,p-1.96*se) if se is not None else None,"ci_high":min(1,p+1.96*se) if se is not None else None}


def summary_row(rows, var):
    stat=weighted_stat(rows,var); return {"variable":var, **stat}

def cross_row(rows, var, cvar, cval):
    stat=weighted_stat(rows,var,lambda r: parse_bool(r.get(cvar,""))==cval)
    return {"group":f"{cvar}={cval}","outcome":var,**stat}

def subgroup_rows(rows, outcome, category, min_n=30):
    cats=sorted({(r.get(category) or "").strip() for r in rows if (r.get(category) or "").strip()})
    out=[]
    for cat in cats:
        stat=weighted_stat(rows,outcome,lambda r,cat=cat:(r.get(category) or "").strip()==cat)
        if stat["n_unweighted"]>=min_n: out.append({"category_variable":category,"category":cat,"outcome":outcome,**stat})
    return out


def fmt_pct(v): return "" if v is None else f"{100*v:.1f}"
def fmt_num(v): return "" if v is None else f"{v:.0f}"

def write_csv(path, rows, headers):
    with path.open("w", newline="", encoding="utf-8") as f:
        w=csv.DictWriter(f, fieldnames=headers); w.writeheader(); w.writerows(rows)


def variable_audit(rows):
    out=[]; total=len(rows)
    audit_vars=["pay_casheqv","EF1","EF2","EF3_a","EF3_b","EF3_c","EF3_h","atleast_okay","B2","EF5C","EF5D","bill_pressure","fs21_any_external_help","credit_constrained","bnpl_late_or_fee","unable_pay_400_now","medical_debt","unexpected_medical_expense","major_medical_concern","low_buffer_both"]
    for var in audit_vars:
        stat=weighted_stat(rows,var)
        doc=VARIABLE_DOC.get(var, ["Author-constructed or selected analysis variable", "See codebook/script", "analysis variable"])
        missing=total-stat["n_unweighted"]
        out.append({"variable":var,"question_or_definition":doc[0],"base_population":doc[1],"type":doc[2],"n_unweighted":stat["n_unweighted"],"missing_n":missing,"missing_rate":missing/total,"weighted_denominator":stat["weighted_denominator"],"weighted_rate":stat["weighted_rate"],"se_approx":stat["se"],"ci_low":stat["ci_low"],"ci_high":stat["ci_high"]})
    return out


def design_matrix(rows, controls):
    # One-hot categorical controls, first category omitted; include intercept and low_buffer_both.
    cats={c:sorted({(r.get(c) or "").strip() for r in rows if (r.get(c) or "").strip()}) for c in controls}
    names=["intercept","low_buffer_both"]
    for c, vals in cats.items():
        for val in vals[1:]: names.append(f"{c}={val}")
    X=[]; keep=[]
    for i,r in enumerate(rows):
        lb=parse_bool(r.get("low_buffer_both"))
        if lb is None: continue
        row=[1.0,float(lb)]
        ok=True
        for c, vals in cats.items():
            val=(r.get(c) or "").strip()
            if not val: ok=False; break
            for level in vals[1:]: row.append(1.0 if val==level else 0.0)
        if ok: X.append(row); keep.append(i)
    return np.array(X,float), keep, names


def wls_lpm(rows, outcome):
    controls=["inc_4cat_50k","educ_4cat","ppagect4","race_5cat","pprent","ppemploy","has_child_under_18","ppreg4"]
    X, idx, names=design_matrix(rows, controls)
    y=[]; w=[]; final=[]
    for j,i in enumerate(idx):
        r=rows[i]; yy=parse_bool(r.get(outcome)); ww=parse_float(r.get("weight"))
        if yy is None or ww is None or ww<=0: continue
        y.append(yy); w.append(ww); final.append(j)
    X=X[final,:]; y=np.array(y,float); w=np.array(w,float)
    if len(y)<50: return None
    sw=np.sqrt(w); Xw=X*sw[:,None]; yw=y*sw
    try:
        XtX=Xw.T@Xw; inv=np.linalg.pinv(XtX); beta=inv@(Xw.T@yw)
        resid=y-X@beta
        meat=(X.T*((w*resid)**2))@X
        cov=inv@meat@inv
        se=np.sqrt(np.maximum(np.diag(cov),0))
        k=names.index("low_buffer_both")
        return {"outcome":outcome,"n_unweighted":len(y),"coef_low_buffer_both":beta[k],"se_robust_approx":se[k],"ci_low":beta[k]-1.96*se[k],"ci_high":beta[k]+1.96*se[k],"controls":"income, education, age, race/ethnicity, tenure, employment, children, region"}
    except Exception:
        return None


def main():
    ensure_dirs(); download_if_needed(); rows=list(selected_rows())
    summary_vars=["pay_casheqv","EF1","EF2","EF3_a","EF3_b","EF3_c","unable_pay_400_now","atleast_okay","financially_vulnerable_b2","bill_pressure","fs21_any_external_help","credit_constrained","medical_debt","unexpected_medical_expense","low_buffer_both","low_savings_pay_overtime","bnpl_late_or_fee"]
    summaries=[summary_row(rows,v) for v in summary_vars]
    outcomes=["atleast_okay","financially_vulnerable_b2","unable_pay_400_now","bill_pressure","fs21_any_external_help","credit_constrained","medical_debt","unexpected_medical_expense"]
    crosses=[]
    for cvar in ["pay_casheqv","EF1","EF3_b","low_buffer_both","low_savings_pay_overtime"]:
        for cval in [0,1]:
            for out in outcomes:
                if out!=cvar: crosses.append(cross_row(rows,out,cvar,cval))
    sub=[]
    for cat in ["inc_4cat_50k","educ_4cat","race_5cat","ppagect4","pprent","ppemploy","has_child_under_18"]:
        for out in ["pay_casheqv","EF1","atleast_okay","financially_vulnerable_b2","bill_pressure"]:
            sub.extend(subgroup_rows(rows,out,cat))
    audit=variable_audit(rows)
    models=[m for m in (wls_lpm(rows,o) for o in ["financially_vulnerable_b2","unable_pay_400_now","bill_pressure","fs21_any_external_help","credit_constrained","medical_debt"]) if m]

    write_csv(PROCESSED/"shed_2025_selected_variables.csv", rows, FIELDS)
    write_csv(TABLES/"shed_2025_weighted_summary.csv", summaries, ["variable","n_unweighted","weighted_denominator","weighted_rate","neff","se","ci_low","ci_high"])
    write_csv(TABLES/"shed_2025_weighted_crosstabs.csv", crosses, ["group","outcome","n_unweighted","weighted_denominator","weighted_rate","neff","se","ci_low","ci_high"])
    write_csv(TABLES/"shed_2025_weighted_subgroups.csv", sub, ["category_variable","category","outcome","n_unweighted","weighted_denominator","weighted_rate","neff","se","ci_low","ci_high"])
    write_csv(TABLES/"shed_2025_variable_audit.csv", audit, ["variable","question_or_definition","base_population","type","n_unweighted","missing_n","missing_rate","weighted_denominator","weighted_rate","se_approx","ci_low","ci_high"])
    write_csv(TABLES/"shed_2025_adjusted_lpm.csv", models, ["outcome","n_unweighted","coef_low_buffer_both","se_robust_approx","ci_low","ci_high","controls"])

    md=["# SHED 2025 Revised Phase A Tables","","Source: Federal Reserve SHED 2025 public-use CSV microdata. CIs are approximate and treat final weights as analysis weights; they are not replicate-weight/design-based intervals.","","## Table A. Variable denominator audit","","| Variable | Base / type | N | Missing % | Weighted rate % | 95% CI % |","|---|---|---:|---:|---:|---:|"]
    for r in audit:
        md.append(f"| `{r['variable']}` | {r['base_population']} / {r['type']} | {r['n_unweighted']:,} | {100*r['missing_rate']:.1f} | {fmt_pct(r['weighted_rate'])} | {fmt_pct(r['ci_low'])}–{fmt_pct(r['ci_high'])} |")
    md += ["","## Table 1. Weighted summary rates","","| Variable | N | Weighted rate % | 95% CI % |","|---|---:|---:|---:|"]
    for r in summaries: md.append(f"| `{r['variable']}` | {r['n_unweighted']:,} | {fmt_pct(r['weighted_rate'])} | {fmt_pct(r['ci_low'])}–{fmt_pct(r['ci_high'])} |")
    md += ["","## Table 2. Selected weighted cross-tabs","","| Group | Outcome | N | Weighted rate % | 95% CI % |","|---|---|---:|---:|---:|"]
    for r in crosses: md.append(f"| `{r['group']}` | `{r['outcome']}` | {r['n_unweighted']:,} | {fmt_pct(r['weighted_rate'])} | {fmt_pct(r['ci_low'])}–{fmt_pct(r['ci_high'])} |")
    md += ["","## Table 3. Adjusted low-buffer associations (approximate weighted LPM)","","| Outcome | N | Low-buffer coefficient (pp) | Robust approx. SE (pp) | 95% CI (pp) | Controls |","|---|---:|---:|---:|---:|---|"]
    for r in models: md.append(f"| `{r['outcome']}` | {r['n_unweighted']:,} | {100*r['coef_low_buffer_both']:.1f} | {100*r['se_robust_approx']:.1f} | {100*r['ci_low']:.1f}–{100*r['ci_high']:.1f} | {r['controls']} |")
    (TABLES/"shed_2025_phase_a_tables.md").write_text("\n".join(md)+"\n")
    manifest={"source_url":ZIP_URL,"zip_path":str(ZIP_PATH.relative_to(ROOT)),"zip_bytes":ZIP_PATH.stat().st_size,"csv_entry":CSV_NAME,"rows":len(rows),"outputs":[str((TABLES/name).relative_to(ROOT)) for name in ["shed_2025_weighted_summary.csv","shed_2025_weighted_crosstabs.csv","shed_2025_weighted_subgroups.csv","shed_2025_variable_audit.csv","shed_2025_adjusted_lpm.csv","shed_2025_phase_a_tables.md"]]}
    (PROCESSED/"shed_2025_phase_a_manifest.json").write_text(json.dumps(manifest,indent=2)+"\n")
    print(json.dumps(manifest,indent=2))

if __name__ == "__main__": main()
