# Paper XI — SHED Microdata Upgrade

This folder starts the next empirical paper after the capstone: a focused SHED microdata analysis of emergency buffers, borrowing responses, and hardship/well-being.

Start with `docs/PAPER_XI_CONCEPT_MEMO_2026-05-14.md`, then run the scripts in `scripts/`.
